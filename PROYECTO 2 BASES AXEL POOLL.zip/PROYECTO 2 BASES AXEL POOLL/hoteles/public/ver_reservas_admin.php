<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

// Consulta de reservas con información relevante
$sql = "
SELECT 
    r.ReservacionID,
    r.NumeroReserva,
    c.Nombre AS Cliente,
    h.NumeroHabitacion,
    th.Nombre AS TipoHabitacion,
    r.FechaIngreso,
    r.FechaSalida,
    r.CantidadPersonas,
    r.PoseeVehiculo
FROM Reservaciones r
JOIN Clientes c ON r.ClienteID = c.ClienteID
JOIN Habitaciones h ON r.HabitacionID = h.HabitacionID
JOIN TiposHabitacion th ON h.TipoHabitacionID = th.TipoHabitacionID
ORDER BY r.FechaIngreso DESC;
";

$resultado = sqlsrv_query($conn, $sql);
if ($resultado === false) {
    die("Error al consultar las reservas: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservas Registradas</title>
</head>
<body>
    <h2>Listado de Reservas</h2>
    <a href="dashboard_admin.php">← Volver al Dashboard</a><br><br>

    <table border="1" cellpadding="6">
        <tr>
            <th>ID</th>
            <th>N° Reserva</th>
            <th>Cliente</th>
            <th>Habitación</th>
            <th>Tipo</th>
            <th>Ingreso</th>
            <th>Salida</th>
            <th>Personas</th>
            <th>Vehículo</th>
            <th>Acciones</th>
        </tr>

        <?php while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo $fila['ReservacionID']; ?></td>
                <td><?php echo $fila['NumeroReserva']; ?></td>
                <td><?php echo $fila['Cliente']; ?></td>
                <td><?php echo $fila['NumeroHabitacion']; ?></td>
                <td><?php echo $fila['TipoHabitacion']; ?></td>
                <td><?php echo $fila['FechaIngreso']->format('Y-m-d'); ?></td>
                <td><?php echo $fila['FechaSalida']->format('Y-m-d'); ?></td>
                <td><?php echo $fila['CantidadPersonas']; ?></td>
                <td><?php echo $fila['PoseeVehiculo'] ? 'Sí' : 'No'; ?></td>
                <td>
                    <a href="editar_reserva_admin.php?id=<?php echo $fila['ReservacionID']; ?>">Editar</a>
                    <a href="../backend/eliminar_reserva.php?id=<?php echo $fila['ReservacionID']; ?>" 
                        onclick="return confirm('¿Está seguro de que desea eliminar esta reserva?');">
                        Eliminar
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>

    </table>
</body>
</html>

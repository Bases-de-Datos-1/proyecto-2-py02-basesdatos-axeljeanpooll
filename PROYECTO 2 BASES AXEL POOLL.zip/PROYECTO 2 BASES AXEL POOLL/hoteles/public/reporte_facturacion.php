<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once("../backend/conexion.php");

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Facturación</title>
</head>
<body>
    <h2>Reporte de Facturación</h2>
    <form action="../backend/procesar_facturacion.php" method="post">
        <label>Desde:</label>
        <input type="date" name="desde"><br><br>

        <label>Hasta:</label>
        <input type="date" name="hasta"><br><br>

        <label>Agrupamiento:</label>
        <select name="agrupamiento">
            <option value="DIA">Día</option>
            <option value="MES">Mes</option>
            <option value="ANIO">Año</option>
        </select><br><br>

        <label>Tipo de Habitación:</label>
        <input type="text" name="tipo_habitacion"><br><br>

        <label>ID de Habitación:</label>
        <input type="number" name="habitacion_id"><br><br>

        <button type="submit">Generar Reporte</button>
        <a href="dashboard_admin.php">← Volver al Dashboard</a>
    </form>
</body>
</html>

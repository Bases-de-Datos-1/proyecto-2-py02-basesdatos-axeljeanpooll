<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once("../backend/conexion.php");

// Intentar cargar los establecimientos
$sql_est = "SELECT EstablecimientoID, NombreHotel FROM Establecimientos";
$stmt_est = sqlsrv_query($conn, $sql_est);

if ($stmt_est === false) {
    echo "Conexión exitosa a la base de datos.";
    echo "Error al cargar establecimientos.";
    print_r(sqlsrv_errors());
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Empresa de Actividad</title>
</head>
<body>
    <h2>Agregar Empresa de Actividad Recreativa</h2>

    <form method="post" action="../backend/procesar_agregar_empresa.php">
        <label for="establecimiento_id">Establecimiento asociado:</label>
        <select name="establecimiento_id" required>
            <option value="">Seleccione...</option>
            <?php while ($row = sqlsrv_fetch_array($stmt_est, SQLSRV_FETCH_ASSOC)): ?>
                <option value="<?php echo $row['EstablecimientoID']; ?>">
                    <?php echo htmlspecialchars($row['NombreHotel']); ?>
                </option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Nombre Empresa:</label>
        <input type="text" name="nombre_empresa" required><br><br>

        <label>Cédula Jurídica:</label>
        <input type="text" name="cedula_juridica" required><br><br>

        <label>Email:</label>
        <input type="email" name="email" required><br><br>

        <label>Teléfono:</label>
        <input type="text" name="telefono" required><br><br>

        <label>Nombre Contacto:</label>
        <input type="text" name="nombre_contacto" required><br><br>

        <label>Provincia:</label>
        <input type="text" name="provincia" required><br><br>

        <label>Cantón:</label>
        <input type="text" name="canton" required><br><br>

        <label>Distrito:</label>
        <input type="text" name="distrito" required><br><br>

        <label>Señas:</label>
        <textarea name="senas" required></textarea><br><br>

        <label>Tipo de Actividad:</label>
        <input type="text" name="tipo_actividad" required><br><br>

        <label>Descripción:</label>
        <textarea name="descripcion"></textarea><br><br>

        <label>Precio:</label>
        <input type="number" name="precio" step="0.01" required><br><br>

        <button type="submit">Agregar Empresa</button>
    </form>

    <br><a href="dashboard_admin.php">← Volver al inicio</a>
</body>
</html>

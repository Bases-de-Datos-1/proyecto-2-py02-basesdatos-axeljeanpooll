<?php
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel del Administrador</title>
</head>
<body>
    <h2>Bienvenido, <?php echo $_SESSION['usuario']; ?></h2>
    <a href="../backend/logout.php">Cerrar sesión</a>
    <!-- Aqui los botones de reportes, cruds y lo que se necesite -->
    <form action="reporte_facturacion.php">
        <button type="submit">Reporte de Facturación</button>
    </form>
    <form action="reporte_uso_por_tipo.php">
        <button type="submit">Ver reporte de uso por tipo</button>
    </form>
    <form action="reporte_edad_clientes.php">
        <button type="submit">Ver reporte de edades de clientes</button>
    </form>
    <form action="reporte_hoteles_demanda.php">
        <button type="submit">Ver reporte de hoteles más demandados</button>
    </form>
</body>
</html>



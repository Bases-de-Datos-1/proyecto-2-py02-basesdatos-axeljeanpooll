<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Administrador</title>
</head>
<body>
    <h1>Bienvenido Administrador: <?php echo $_SESSION['usuario']; ?></h1>
    <a href="../backend/logout.php">Cerrar sesión</a>
    <br><br>

    <h2>Funcionalidades disponibles:</h2>
    <ul>
        <li><a href="ir_a_hoteles_desde_admin.php">Ver Hoteles</a></li>
        <li><a href="ver_establecimientos.php">Mantenimiento de hoteles</a></li>
        <li><a href="ver_tipos_habitacion.php">Mantenimiento de tipos de habitación</a></li>
        <li><a href="ver_habitaciones.php">Mantenimiento de habitaciones</a></li>
        <li><a href="ver_clientes.php">Mantenimiento de cliente</a></li>
        <li><a href="ver_empresas.php">Mantenimiento de empresa</a></li>
        <li><a href="ver_servicios.php">Mantenimiento de actividades</a></li>
        <li><a href="ver_reservas_admin.php">Ver Reservas</a></li>
        <li><a href="facturar_reserva.php">Facturación</a></li>
        <li><a href="reporte_facturacion.php">Reporte de Facturación</a></li>
        <li><a href="reporte_uso_por_tipo.php">Reporte de Uso por Tipo</a></li>
        <li><a href="reporte_edad_clientes.php">Reporte de Edades de Clientes</a></li>
        <li><a href="reporte_hoteles_demanda.php">Reporte de Hoteles por Demanda</a></li>
    </ul>
</body>
</html>

<?php
require_once("../backend/conexion.php");
session_start();

// Mostrar mensaje de error si viene de redirección
$error = isset($_GET['error']) ? $_GET['error'] : '';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Cliente</title>
</head>
<body>
    <h2>Registro de Nuevo Cliente</h2>

    <?php if ($error): ?>
        <p style="color: red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form action="../backend/procesar_registro_cliente.php" method="post">
        <label>Nombre:</label><br>
        <input type="text" name="nombre" required><br><br>

        <label>Primer Apellido:</label><br>
        <input type="text" name="apellido1" required><br><br>

        <label>Segundo Apellido:</label><br>
        <input type="text" name="apellido2" required><br><br>

        <label>Fecha de Nacimiento:</label><br>
        <input type="date" name="fecha_nacimiento" required><br><br>

        <label>Tipo de Identificación:</label><br>
        <select name="tipo_identificacion" required>
            <option value="">-- Seleccione --</option>
            <option value="Nacional">Nacional</option>
            <option value="Pasaporte">Pasaporte</option>
            <option value="Otro">Otro</option>
        </select><br><br>

        <label>Cédula / Identificación:</label><br>
        <input type="text" name="cedula" required><br><br>

        <label>País de Residencia:</label><br>
        <input type="text" name="pais" required><br><br>

        <label>Provincia (solo CR):</label><br>
        <input type="text" name="provincia"><br><br>

        <label>Cantón (solo CR):</label><br>
        <input type="text" name="canton"><br><br>

        <label>Distrito (solo CR):</label><br>
        <input type="text" name="distrito"><br><br>

        <label>Teléfono 1:</label><br>
        <input type="text" name="telefono1" required><br><br>

        <label>Teléfono 2 (opcional):</label><br>
        <input type="text" name="telefono2"><br><br>

        <label>Teléfono 3 (opcional):</label><br>
        <input type="text" name="telefono3"><br><br>

        <label>Nombre de Usuario:</label><br>
        <input type="text" name="usuario" required><br><br>

        <label>Contraseña:</label><br>
        <input type="password" name="clave" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <button type="submit">Registrarse</button>
    </form>

    <br>
    <a href="main.php">Volver al inicio</a>
</body>
</html>

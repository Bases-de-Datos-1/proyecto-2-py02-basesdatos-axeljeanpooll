<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar que sea un cliente autenticado
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'cliente') {
    header("Location: login_cliente.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Cliente</title>
</head>
<body>
    <h1>Bienvenido Cliente: <?php echo $_SESSION['usuario']; ?></h1>
    <a href="../backend/logout.php">Cerrar sesión</a>
    <br><br>

    <h2>Opciones disponibles:</h2>
    <ul>
        <li><a href="ir_a_hoteles_desde_cliente.php">Ver Hoteles</a></li>
        <li><a href="buscar_actividades.php">Buscar actividades</a></li>
        <li><a href="reservas_clientes.php">Realizar Reserva</a></li>
        <li><a href="mis_reservas.php">Consultar mis reservas</a></li>
        <li><a href="perfil_cliente.php">Consultar Información de Cliente</a></li>
        <li><a href="historial_reservas.php">Historial de Reservas</a></li>
    </ul>
</body>
</html>

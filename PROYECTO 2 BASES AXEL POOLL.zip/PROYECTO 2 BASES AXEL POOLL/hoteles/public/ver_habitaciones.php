<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

$sql = "{CALL sp_GetHabitaciones (?, ?)}"; // Parametros nulos para obtener todas
$params = [null, null];
$resultado = sqlsrv_query($conn, $sql, $params);

if ($resultado === false) {
    die("Error al consultar las habitaciones: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Habitaciones</title>
</head>
<?php
if (isset($_GET['mensaje'])) {
    $mensajes = [
        'ok' => 'Habitación eliminada correctamente.',
        'relacionada' => 'No se puede eliminar la habitación porque tiene reservas asociadas.',
        'error_eliminacion' => 'Error al eliminar la habitación.',
        'error_id' => 'ID de habitación inválido.',
        'error_bd' => 'Error al acceder a la base de datos.'
    ];
    
    $tipo = ($_GET['mensaje'] === 'ok') ? 'green' : 'red';
    echo "<p style='color: $tipo; font-weight: bold;'>{$mensajes[$_GET['mensaje']]}</p>";
}
?>
<body>
    <h2>Lista de Habitaciones</h2>
    <a href="dashboard_admin.php">← Volver al Dashboard</a><br><br>
    <a href="agregar_habitacion.php">Agregar nueva habitación</a><br><br>

    <table border="1" cellpadding="6">
        <tr>
            <th>ID</th>
            <th>Número</th>
            <th>Hotel</th>
            <th>Tipo</th>
            <th>Acciones</th>
        </tr>

        <?php while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo $fila['HabitacionID']; ?></td>
                <td><?php echo htmlspecialchars($fila['NumeroHabitacion']); ?></td>
                <td><?php echo htmlspecialchars($fila['NombreHotel']); ?></td>
                <td><?php echo htmlspecialchars($fila['Tipo']); ?></td>
                <td>
                    <a href="editar_habitacion.php?id=<?php echo $fila['HabitacionID']; ?>">Editar</a> |
                    <a href="../backend/eliminar_habitacion.php?id=<?php echo $fila['HabitacionID']; ?>"
                       onclick="return confirm('¿Está seguro de eliminar esta habitación?');">Eliminar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

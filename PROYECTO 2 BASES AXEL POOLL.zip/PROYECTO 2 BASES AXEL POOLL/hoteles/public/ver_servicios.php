<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

// Consulta de actividades recreativas con el nombre del hotel
$sql = "{CALL sp_GetActividades}";
$resultado = sqlsrv_query($conn, $sql);

if ($resultado === false) {
    die("Error al consultar actividades: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Actividades Recreativas</title>
</head>
<body>
    <h2>Actividades Recreativas Registradas</h2>
    <a href="dashboard_admin.php">← Volver al Dashboard</a><br><br>
    <a href="agregar_servicio.php">Agregar nueva actividad</a><br><br>

    <table border="1" cellpadding="6">
        <tr>
            <th>ID</th>
            <th>Hotel</th>
            <th>Empresa</th>
            <th>Tipo de Actividad</th>
            <th>Precio</th>
            <th>Acciones</th>
        </tr>

        <?php while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo $fila['ActividadID']; ?></td>
                <td><?php echo htmlspecialchars($fila['NombreHotel']); ?></td>
                <td><?php echo htmlspecialchars($fila['NombreEmpresa']); ?></td>
                <td><?php echo htmlspecialchars($fila['TipoActividad']); ?></td>
                <td><?php echo number_format($fila['Precio'], 2); ?></td>
                <td>
                    <a href="editar_servicio.php?id=<?php echo $fila['ActividadID']; ?>">Editar</a> |
                    <a href="../backend/eliminar_servicio.php?id=<?php echo $fila['ActividadID']; ?>"
                       onclick="return confirm('¿Desea eliminar esta actividad?');">Eliminar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<?php
session_start();
$_SESSION['origen_hoteles'] = 'admin';
header('Location: buscar_hoteles.php');
exit();

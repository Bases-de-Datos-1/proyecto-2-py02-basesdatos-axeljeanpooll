<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Hotel</title>
</head>
<body>
    <h2>Agregar Nuevo Hotel</h2>
    <a href="ver_establecimientos.php">← Volver</a><br><br>

    <form action="../backend/procesar_agregar_establecimiento.php" method="post">
        <label>Nombre del Hotel:</label><br>
        <input type="text" name="nombre" required><br><br>

        <label>Cédula Jurídica:</label><br>
        <input type="text" name="cedula" required><br><br>

        <label>Tipo:</label><br>
        <input type="text" name="tipo" required><br><br>

        <label>Provincia:</label><br>
        <input type="text" name="provincia" required><br><br>

        <label>Cantón:</label><br>
        <input type="text" name="canton" required><br><br>

        <label>Distrito:</label><br>
        <input type="text" name="distrito" required><br><br>

        <label>Barrio:</label><br>
        <input type="text" name="barrio" required><br><br>

        <label>Señas:</label><br>
        <textarea name="senas" required></textarea><br><br>

        <label>Referencia:</label><br>
        <input type="text" name="referencia"><br><br>

        <label>Teléfonos:</label><br>
        <input type="text" name="telefonos"><br><br>

        <label>Email:</label><br>
        <input type="email" name="email"><br><br>

        <label>Sitio Web:</label><br>
        <input type="text" name="sitio"><br><br>

        <label>Facebook:</label><br>
        <input type="text" name="facebook"><br><br>

        <label>Instagram:</label><br>
        <input type="text" name="instagram"><br><br>

        <label>YouTube:</label><br>
        <input type="text" name="youtube"><br><br>

        <label>TikTok:</label><br>
        <input type="text" name="tiktok"><br><br>

        <label>Threads:</label><br>
        <input type="text" name="threads"><br><br>

        <label>X (Twitter):</label><br>
        <input type="text" name="x"><br><br>

        <label>Lista de Servicios:</label><br>
        <input type="text" name="servicios"><br><br>

        <button type="submit">Guardar Hotel</button>
    </form>
</body>
</html>

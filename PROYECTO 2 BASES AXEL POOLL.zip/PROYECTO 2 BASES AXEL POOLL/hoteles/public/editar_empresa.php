<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once("../backend/conexion.php");

$empresa_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($empresa_id <= 0) {
    echo "ID de empresa no valido.";
    exit();
}

// Obtener datos de la empresa
$sql = "SELECT * FROM ActividadesRecreacion WHERE ActividadID = ?";
$params = [$empresa_id];
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false || !($empresa = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))) {
    echo "Error al obtener la informacion de la empresa.";
    exit();
}

// Obtener establecimientos para el dropdown
$sql_est = "SELECT EstablecimientoID, NombreHotel FROM Establecimientos";
$stmt_est = sqlsrv_query($conn, $sql_est);
$establecimientos = [];

while ($fila = sqlsrv_fetch_array($stmt_est, SQLSRV_FETCH_ASSOC)) {
    $establecimientos[] = $fila;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Empresa</title>
</head>
<body>
    <h2>Editar Empresa de Actividad Recreativa</h2>
    <form action="../backend/procesar_editar_empresa.php" method="post">
        <input type="hidden" name="id" value="<?php echo $empresa_id; ?>">

        <label>Establecimiento:</label>
        <select name="establecimiento_id" required>
            <?php foreach ($establecimientos as $e): ?>
                <option value="<?php echo $e['EstablecimientoID']; ?>" <?php if ($empresa['EstablecimientoID'] == $e['EstablecimientoID']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($e['NombreHotel']); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Nombre de la empresa:</label>
        <input type="text" name="nombre" value="<?php echo htmlspecialchars($empresa['NombreEmpresa']); ?>" required><br><br>

        <label>Cedula juridica:</label>
        <input type="text" name="cedula" value="<?php echo htmlspecialchars($empresa['CedulaJuridica']); ?>" required><br><br>

        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($empresa['Email']); ?>" required><br><br>

        <label>Telefono:</label>
        <input type="text" name="telefono" value="<?php echo htmlspecialchars($empresa['Telefono']); ?>" required><br><br>

        <label>Nombre del contacto:</label>
        <input type="text" name="contacto" value="<?php echo htmlspecialchars($empresa['NombreContacto']); ?>" required><br><br>

        <label>Provincia:</label>
        <input type="text" name="provincia" value="<?php echo htmlspecialchars($empresa['Provincia']); ?>" required><br><br>

        <label>Canton:</label>
        <input type="text" name="canton" value="<?php echo htmlspecialchars($empresa['Canton']); ?>" required><br><br>

        <label>Distrito:</label>
        <input type="text" name="distrito" value="<?php echo htmlspecialchars($empresa['Distrito']); ?>" required><br><br>

        <label>Señas:</label>
        <input type="text" name="senas" value="<?php echo htmlspecialchars($empresa['Senas']); ?>" required><br><br>

        <label>Tipo de actividad:</label>
        <input type="text" name="tipo" value="<?php echo htmlspecialchars($empresa['TipoActividad']); ?>" required><br><br>

        <label>Descripcion:</label>
        <input type="text" name="descripcion" value="<?php echo htmlspecialchars($empresa['Descripcion']); ?>"><br><br>

        <label>Precio:</label>
        <input type="number" step="0.01" name="precio" value="<?php echo htmlspecialchars($empresa['Precio']); ?>" required><br><br>

        <button type="submit">Guardar cambios</button>
    </form>
    <br><a href="ver_empresas.php">← Volver al listado</a>
</body>
</html>

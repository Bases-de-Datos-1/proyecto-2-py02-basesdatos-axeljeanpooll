<?php
// Este archivo se encarga de establecer el origen de la vista de hoteles como "main"
// para que buscar_hoteles.php sepa a donde debe regresar el usuario si no ha iniciado sesion

session_start();
$_SESSION['origen_hoteles'] = 'main';

// Redirige al buscador de hoteles
header('Location: buscar_hoteles.php');
exit();

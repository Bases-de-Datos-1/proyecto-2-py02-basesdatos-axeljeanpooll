<?php
session_start();
$_SESSION['origen_hoteles'] = 'cliente';
header('Location: buscar_hoteles.php');
exit();
<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

if (!isset($_GET['id'])) {
    die("ID de tipo de habitación no especificado.");
}

$id = intval($_GET['id']);

$sql = "{CALL sp_GetTipoHabitacionByID(?)}";
$params = [$id];
$stmt = sqlsrv_query($conn, $sql, $params);


if ($stmt === false || !($tipo = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))) {
    die("Tipo de habitación no encontrado.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Tipo de Habitación</title>
</head>
<body>
    <h2>Editar Tipo de Habitación</h2>
    <a href="ver_tipos_habitacion.php">← Volver al listado</a><br><br>

    <form action="../backend/editar_tipo_habitacion.php" method="post">
        <input type="hidden" name="id" value="<?php echo $tipo['TipoHabitacionID']; ?>">

        <label>Nombre:</label><br>
        <input type="text" name="nombre" value="<?php echo $tipo['Nombre']; ?>" required><br><br>

        <label>Descripción:</label><br>
        <textarea name="descripcion" rows="3"><?php echo $tipo['Descripcion']; ?></textarea><br><br>

        <label>Comodidades:</label><br>
        <textarea name="comodidades" rows="2"><?php echo $tipo['Comodidades']; ?></textarea><br><br>

        <label>Precio (₡):</label><br>
        <input type="number" step="0.01" name="precio" value="<?php echo $tipo['Precio']; ?>" required><br><br>

        <label>Ruta de foto:</label><br>
        <input type="text" name="foto" value="<?php echo $tipo['Fotos']; ?>"><br><br>

        <button type="submit">Guardar cambios</button>
    </form>
</body>
</html>

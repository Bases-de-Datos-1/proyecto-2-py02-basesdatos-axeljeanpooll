<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

$id = $_GET['id'] ?? '';
if ($id === '') {
    die("ID de habitación no proporcionado.");
}

// Obtener la habitación
$sql = "SELECT * FROM vw_HabitacionesExtendida WHERE HabitacionID = ?";
$stmt = sqlsrv_query($conn, $sql, [$id]);
$habitacion = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if (!$habitacion) {
    die("Habitación no encontrada.");
}

// Obtener lista de establecimientos
$sqlEst = "SELECT EstablecimientoID, NombreHotel FROM Establecimientos";
$resEst = sqlsrv_query($conn, $sqlEst);
$establecimientos = [];
while ($fila = sqlsrv_fetch_array($resEst, SQLSRV_FETCH_ASSOC)) {
    $establecimientos[] = $fila;
}

// Obtener lista de tipos de habitación
$sqlTipo = "SELECT TipoHabitacionID, Nombre FROM TiposHabitacion";
$resTipo = sqlsrv_query($conn, $sqlTipo);
$tipos = [];
while ($fila = sqlsrv_fetch_array($resTipo, SQLSRV_FETCH_ASSOC)) {
    $tipos[] = $fila;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Habitación</title>
</head>
<body>
    <h2>Editar Habitación</h2>
    <a href="ver_habitaciones.php">← Volver a la lista</a><br><br>

    <form action="../backend/procesar_edicion_habitacion.php" method="post">
        <input type="hidden" name="id" value="<?php echo $habitacion['HabitacionID']; ?>">

        <label>Número de Habitación:</label><br>
        <input type="text" name="numero" value="<?php echo htmlspecialchars($habitacion['NumeroHabitacion']); ?>" required><br><br>

        <label>Establecimiento:</label><br>
        <select name="establecimiento_id" required>
            <?php foreach ($establecimientos as $est): ?>
                <option value="<?php echo $est['EstablecimientoID']; ?>" <?php if ($est['EstablecimientoID'] == $habitacion['EstablecimientoID']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($est['NombreHotel']); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Tipo de Habitación:</label><br>
        <select name="tipo_id" required>
            <?php foreach ($tipos as $tipo): ?>
                <option value="<?php echo $tipo['TipoHabitacionID']; ?>" <?php if ($tipo['TipoHabitacionID'] == $habitacion['TipoHabitacionID']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($tipo['Nombre']); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <button type="submit">Guardar Cambios</button>
    </form>
</body>
</html>

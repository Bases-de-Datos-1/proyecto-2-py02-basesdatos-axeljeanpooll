<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

// Obtener lista de establecimientos
$sqlEst = "SELECT EstablecimientoID, NombreHotel FROM Establecimientos";
$resEst = sqlsrv_query($conn, $sqlEst);
$establecimientos = [];
while ($fila = sqlsrv_fetch_array($resEst, SQLSRV_FETCH_ASSOC)) {
    $establecimientos[] = $fila;
}

// Obtener lista de tipos de habitación
$sqlTipo = "SELECT TipoHabitacionID, Nombre FROM TiposHabitacion";
$resTipo = sqlsrv_query($conn, $sqlTipo);
$tipos = [];
while ($fila = sqlsrv_fetch_array($resTipo, SQLSRV_FETCH_ASSOC)) {
    $tipos[] = $fila;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Habitación</title>
</head>
<body>
    <h2>Agregar Nueva Habitación</h2>
    <a href="ver_habitaciones.php">← Volver a la lista</a><br><br>

    <form action="../backend/procesar_agregar_habitacion.php" method="post">
        <label for="numero">Número de Habitación:</label><br>
        <input type="text" name="numero" required><br><br>

        <label for="establecimiento">Establecimiento:</label><br>
        <select name="establecimiento_id" required>
            <option value="">-- Seleccione --</option>
            <?php foreach ($establecimientos as $est): ?>
                <option value="<?php echo $est['EstablecimientoID']; ?>">
                    <?php echo htmlspecialchars($est['NombreHotel']); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="tipo">Tipo de Habitación:</label><br>
        <select name="tipo_id" required>
            <option value="">-- Seleccione --</option>
            <?php foreach ($tipos as $tipo): ?>
                <option value="<?php echo $tipo['TipoHabitacionID']; ?>">
                    <?php echo htmlspecialchars($tipo['Nombre']); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <button type="submit">Agregar Habitación</button>
    </form>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'cliente') {
    header("Location: login_cliente.html");
    exit;
}

require_once("../backend/conexion.php");

// Obtener ID del cliente
$usuario = $_SESSION['usuario'];
$sqlID = "SELECT ClienteID FROM Clientes WHERE Usuario = ?";
$stmtID = sqlsrv_query($conn, $sqlID, array($usuario));
$cliente = sqlsrv_fetch_array($stmtID, SQLSRV_FETCH_ASSOC);
$clienteID = $cliente['ClienteID'] ?? null;

$reservas = [];

if ($clienteID) {
    $sql = "SELECT r.NumeroReserva, r.FechaIngreso, r.FechaSalida, r.CantidadPersonas, r.PoseeVehiculo,
                   h.NumeroHabitacion, t.Nombre AS TipoHabitacion
            FROM Reservaciones r
            JOIN Habitaciones h ON r.HabitacionID = h.HabitacionID
            JOIN TiposHabitacion t ON h.TipoHabitacionID = t.TipoHabitacionID
            WHERE r.ClienteID = ?
            ORDER BY r.FechaIngreso DESC";

    $stmt = sqlsrv_query($conn, $sql, array($clienteID));
    if ($stmt !== false) {
        while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $reservas[] = $fila;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Reservas</title>
</head>
<body>
    <h2>Mis Reservas</h2>
    
    <br><br>

    <?php if (count($reservas) > 0): ?>
        <table border="1" cellpadding="5">
            <tr>
                <th>Reserva</th>
                <th>Ingreso</th>
                <th>Salida</th>
                <th>Habitación</th>
                <th>Tipo</th>
                <th>Personas</th>
                <th>Vehículo</th>
            </tr>
            <?php foreach ($reservas as $r): ?>
                <tr>
                    <td><?php echo $r['NumeroReserva']; ?></td>
                    <td><?php echo $r['FechaIngreso']->format('Y-m-d'); ?></td>
                    <td><?php echo $r['FechaSalida']->format('Y-m-d'); ?></td>
                    <td><?php echo $r['NumeroHabitacion']; ?></td>
                    <td><?php echo $r['TipoHabitacion']; ?></td>
                    <td><?php echo $r['CantidadPersonas']; ?></td>
                    <td><?php echo $r['PoseeVehiculo'] ? 'Sí' : 'No'; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <a href="dashboard_cliente.php">← Volver al Dashboard</a>
    <?php else: ?>
        <p>No se encontraron reservas realizadas.</p>
    <?php endif; ?>
</body>
</html>

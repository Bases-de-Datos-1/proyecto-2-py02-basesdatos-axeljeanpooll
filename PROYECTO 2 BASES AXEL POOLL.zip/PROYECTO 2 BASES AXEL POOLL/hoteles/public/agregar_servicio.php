<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

// Obtener hoteles disponibles usando procedimiento almacenado
$sql = "{CALL sp_listar_establecimientos()}";  // Usamos el procedimiento adecuado
$stmt = sqlsrv_query($conn, $sql);

if ($stmt === false) {
    die("Error al obtener hoteles: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Actividad Recreativa</title>
</head>
<body>
    <h2>Agregar Actividad Recreativa</h2>
    <a href="ver_servicios.php">← Volver al listado</a><br><br>

    <form action="../backend/procesar_agregar_servicio.php" method="post">
        <label>Hotel asociado:</label><br>
        <select name="establecimiento_id" required>
            <option value="">-- Seleccione un hotel --</option>
            <?php while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) : ?>
                <option value="<?php echo $fila['EstablecimientoID']; ?>">
                    <?php echo htmlspecialchars($fila['NombreHotel']); ?>
                </option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Nombre de la empresa:</label><br>
        <input type="text" name="nombre_empresa" required><br><br>

        <label>Cédula jurídica:</label><br>
        <input type="text" name="cedula_juridica" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Teléfono:</label><br>
        <input type="text" name="telefono" required><br><br>

        <label>Nombre del contacto:</label><br>
        <input type="text" name="nombre_contacto" required><br><br>

        <label>Provincia:</label><br>
        <input type="text" name="provincia" required><br><br>

        <label>Cantón:</label><br>
        <input type="text" name="canton" required><br><br>

        <label>Distrito:</label><br>
        <input type="text" name="distrito" required><br><br>

        <label>Señas:</label><br>
        <textarea name="senas" required></textarea><br><br>

        <label>Tipo de actividad:</label><br>
        <input type="text" name="tipo_actividad" required><br><br>

        <label>Descripción (opcional):</label><br>
        <textarea name="descripcion"></textarea><br><br>

        <label>Precio:</label><br>
        <input type="number" step="0.01" name="precio" required><br><br>

        <button type="submit">Agregar actividad</button>
    </form>
</body>
<

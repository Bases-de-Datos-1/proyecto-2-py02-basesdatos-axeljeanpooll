<?php
session_start();
require_once("../backend/conexion.php");

// Verificar sesión de cliente
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'cliente') {
    header("Location: login_cliente.html");
    exit;
}

// Obtener los datos del cliente
$usuario = $_SESSION['usuario'];
$sql = "SELECT * FROM Clientes WHERE Usuario = ?";
$params = [$usuario];
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false || !($cliente = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))) {
    die("Error al obtener los datos del cliente.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Perfil del Cliente</title>
</head>
<body>
    <h2>Perfil de Cliente: <?php echo htmlspecialchars($cliente['Usuario']); ?></h2>

    <?php if (isset($_GET['mensaje'])): ?>
        <p style="color:green;"><?php echo htmlspecialchars($_GET['mensaje']); ?></p>
    <?php elseif (isset($_GET['error'])): ?>
        <p style="color:red;"><?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php endif; ?>

    <form action="../backend/procesar_actualizacion_cliente.php" method="post">
        <label>Nombre:</label><br>
        <input type="text" name="nombre" value="<?php echo $cliente['Nombre']; ?>" required><br><br>

        <label>Primer Apellido:</label><br>
        <input type="text" name="apellido1" value="<?php echo $cliente['PrimerApellido']; ?>" required><br><br>

        <label>Segundo Apellido:</label><br>
        <input type="text" name="apellido2" value="<?php echo $cliente['SegundoApellido']; ?>"><br><br>

        <label>Fecha de Nacimiento:</label><br>
        <input type="date" name="fecha_nacimiento" value="<?php echo $cliente['FechaNacimiento']->format('Y-m-d'); ?>" required><br><br>

        <label>Tipo de Identificación:</label><br>
        <input type="text" name="tipo_identificacion" value="<?php echo $cliente['TipoIdentificacion']; ?>" required><br><br>

        <label>Cédula:</label><br>
        <input type="text" value="<?php echo $cliente['Cedula']; ?>" disabled><br><br>

        <label>País de Residencia:</label><br>
        <input type="text" name="pais" value="<?php echo $cliente['PaisResidencia']; ?>" required><br><br>

        <label>Provincia:</label><br>
        <input type="text" name="provincia" value="<?php echo $cliente['Provincia']; ?>"><br><br>

        <label>Cantón:</label><br>
        <input type="text" name="canton" value="<?php echo $cliente['Canton']; ?>"><br><br>

        <label>Distrito:</label><br>
        <input type="text" name="distrito" value="<?php echo $cliente['Distrito']; ?>"><br><br>

        <label>Teléfono 1:</label><br>
        <input type="text" name="telefono1" value="<?php echo $cliente['Telefono1']; ?>" required><br><br>

        <label>Teléfono 2:</label><br>
        <input type="text" name="telefono2" value="<?php echo $cliente['Telefono2']; ?>"><br><br>

        <label>Teléfono 3:</label><br>
        <input type="text" name="telefono3" value="<?php echo $cliente['Telefono3']; ?>"><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo $cliente['Email']; ?>" required><br><br>

        <label>Contraseña:</label><br>
        <input type="password" name="clave" value="<?php echo $cliente['Clave']; ?>" required><br><br>

        <button type="submit">Guardar Cambios</button>
    </form>

    <br>
    <a href="dashboard_cliente.php">← Volver al Dashboard</a>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once("../backend/conexion.php");

$sql = "SELECT * FROM vw_EmpresasAliadas ORDER BY NombreEmpresa ASC";
$stmt = sqlsrv_query($conn, $sql);

if ($stmt === false) {
    die("Error al consultar las empresas: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Empresas Aliadas</title>
</head>
<body>
    <h2>Empresas que Ofrecen Actividades</h2>

    <a href="agregar_empresa.php">Agregar Nueva Empresa</a><br><br>

    <table border="1" cellpadding="6">
        <tr>
            <th>Nombre Empresa</th>
            <th>Teléfono</th>
            <th>Email</th>
            <th>Provincia</th>
            <th>Tipo Actividad</th>
            <th>Acciones</th>
        </tr>

        <?php while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo $fila['NombreEmpresa']; ?></td>
                <td><?php echo $fila['Telefono']; ?></td>
                <td><?php echo $fila['Email']; ?></td>
                <td><?php echo $fila['Provincia']; ?></td>
                <td><?php echo $fila['TipoActividad']; ?></td>
                <td>
                    <a href="editar_empresa.php?id=<?php echo $fila['ActividadID']; ?>">Editar</a> |
                    <a href="../backend/eliminar_empresa.php?id=<?php echo $fila['ActividadID']; ?>"
                       onclick="return confirm('¿Está seguro de eliminar esta empresa?');">Eliminar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <br><a href="dashboard_admin.php">← Volver al dashboard</a>
</body>
</html>

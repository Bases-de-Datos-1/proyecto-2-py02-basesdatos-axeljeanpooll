<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Tipo de Habitación</title>
</head>
<body>
    <h2>Crear Tipo de Habitación</h2>
    <a href="ver_tipos_habitacion.php">← Volver al listado</a><br><br>

    <form action="../backend/crear_tipo_habitacion.php" method="post">
        <label>Nombre:</label><br>
        <input type="text" name="nombre" required><br><br>

        <label>Descripción:</label><br>
        <textarea name="descripcion" rows="3"></textarea><br><br>

        <label>Comodidades:</label><br>
        <textarea name="comodidades" rows="2"></textarea><br><br>

        <label>Precio (₡):</label><br>
        <input type="number" step="0.01" name="precio" required><br><br>

        <label>Ruta de foto:</label><br>
        <input type="text" name="foto"><br><br>

        <button type="submit">Guardar</button>
    </form>
</body>
</html>

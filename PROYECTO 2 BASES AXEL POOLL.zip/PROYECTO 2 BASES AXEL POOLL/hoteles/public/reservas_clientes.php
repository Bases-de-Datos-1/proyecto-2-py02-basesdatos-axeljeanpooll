<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'cliente') {
    header("Location: login_cliente.html");
    exit;
}

require_once("../backend/conexion.php");

// Consultar habitaciones disponibles para mostrar
$sql = "SELECT h.HabitacionID, h.NumeroHabitacion, t.Nombre AS TipoNombre
        FROM Habitaciones h
        JOIN TiposHabitacion t ON h.TipoHabitacionID = t.TipoHabitacionID";
$resultado = sqlsrv_query($conn, $sql);

if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Recolectar los resultados en un arreglo
$habitaciones = [];
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    $habitaciones[] = $fila;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservar Habitación</title>
</head>
<body>
    <h2>Formulario de Reserva</h2>
    <form action="../backend/procesar_reserva.php" method="post">
        <label for="habitacion_id">Seleccione una habitación:</label><br>
        <select name="habitacion_id" required>
            <option value="">-- Seleccione --</option>
            <?php foreach ($habitaciones as $hab): ?>
                <option value="<?php echo $hab['HabitacionID']; ?>">
                    <?php echo $hab['NumeroHabitacion'] . " - " . $hab['TipoNombre']; ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Fecha de ingreso:</label><br>
        <input type="date" name="fecha_ingreso" required><br><br>

        <label>Fecha de salida:</label><br>
        <input type="date" name="fecha_salida" required><br><br>

        <label>Cantidad de personas:</label><br>
        <input type="number" name="cantidad_personas" min="1" required><br><br>

        <label>¿Posee vehículo?</label><br>
        <select name="posee_vehiculo" required>
            <option value="0">No</option>
            <option value="1">Sí</option>
        </select><br><br>

        <button type="submit">Reservar</button>
        <a href="dashboard_cliente.php">Volver</a>

    </form>
</body>
</html>

<?php
require_once("../backend/conexion.php");
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'cliente') {
    header("Location: login_cliente.html");
    exit();
}

// Obtener filtros desde el formulario
$empresa = isset($_GET['empresa']) ? trim($_GET['empresa']) : null;
$tipo = isset($_GET['tipo']) ? trim($_GET['tipo']) : null;
$provincia = isset($_GET['provincia']) ? trim($_GET['provincia']) : null;

// Si el valor es cadena vacía, convertirlo en NULL
$empresa = ($empresa === '') ? null : $empresa;
$tipo = ($tipo === '') ? null : $tipo;
$provincia = ($provincia === '') ? null : $provincia;

// Llamar al procedimiento almacenado
$sql = "{CALL sp_BuscarActividades(?, ?, ?)}";
$params = [$empresa, $tipo, $provincia];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    echo "Error al buscar actividades: ";
    print_r(sqlsrv_errors());
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar Actividades Recreativas</title>
    <script>
        function toggleDetalles(id) {
            const detalles = document.getElementById("detalles-" + id);
            if (detalles.style.display === "none") {
                detalles.style.display = "block";
            } else {
                detalles.style.display = "none";
            }
        }
    </script>
</head>
<body>
    <h2>Buscar Actividades Recreativas</h2>
    <form method="get">
        <label>Nombre de la empresa:</label>
        <input type="text" name="empresa" value="<?php echo htmlspecialchars($empresa); ?>"><br><br>

        <label>Tipo de actividad:</label>
        <input type="text" name="tipo" value="<?php echo htmlspecialchars($tipo); ?>"><br><br>

        <label>Provincia:</label>
        <input type="text" name="provincia" value="<?php echo htmlspecialchars($provincia); ?>"><br><br>

        <button type="submit">Buscar</button>
    </form>

    <h3>Resultados:</h3>
    <table border="1" cellpadding="6">
        <tr>
            <th>Empresa</th>
            <th>Tipo Actividad</th>
            <th>Provincia</th>
            <th>Precio</th>
            <th>Contacto</th>
            <th>Accion</th>
        </tr>
        <?php while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)): ?>
            <tr>
                <td><?php echo htmlspecialchars($fila['NombreEmpresa']); ?></td>
                <td><?php echo htmlspecialchars($fila['TipoActividad']); ?></td>
                <td><?php echo htmlspecialchars($fila['Provincia']); ?></td>
                <td>₡<?php echo number_format($fila['Precio'], 2); ?></td>
                <td><?php echo htmlspecialchars($fila['Email']); ?> / <?php echo htmlspecialchars($fila['Telefono']); ?></td>
                <td>
                    <button type="button" onclick="toggleDetalles(<?php echo $fila['ActividadID']; ?>)">Ver más</button>
                </td>
            </tr>
            <tr id="detalles-<?php echo $fila['ActividadID']; ?>" style="display:none;">
                <td colspan="6">
                    <strong>Contacto:</strong> <?php echo htmlspecialchars($fila['NombreContacto']); ?><br>
                    <strong>Dirección:</strong> <?php echo htmlspecialchars($fila['Canton']) . ", " . htmlspecialchars($fila['Distrito']); ?><br>
                    <strong>Señas:</strong> <?php echo htmlspecialchars($fila['Senas']); ?><br>
                    <strong>Descripción:</strong> <?php echo htmlspecialchars($fila['Descripcion'] ?? 'No disponible'); ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <br><a href="dashboard_cliente.php">← Volver al inicio</a>
</body>
</html>

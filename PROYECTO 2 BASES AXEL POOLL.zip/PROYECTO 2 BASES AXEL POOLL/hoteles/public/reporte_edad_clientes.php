<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once("../backend/conexion.php");

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Edad de Clientes</title>
</head>
<body>
    <h2>Reporte de Edad de Clientes</h2>
    <form action="../backend/procesar_edad_clientes.php" method="post">
        <label>Desde:</label>
        <input type="date" name="desde"><br><br>

        <label>Hasta:</label>
        <input type="date" name="hasta"><br><br>

        <button type="submit">Generar Reporte</button>
        <a href="dashboard_admin.php">← Volver al Dashboard</a>
    </form>
</body>
</html>

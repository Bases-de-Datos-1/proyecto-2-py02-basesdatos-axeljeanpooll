<?php
require_once("../backend/conexion.php");
session_start();


$destino = 'main.php'; // valor por defecto

if (isset($_SESSION['origen_hoteles'])) {
    if ($_SESSION['origen_hoteles'] === 'cliente') {
        $destino = 'dashboard_cliente.php';
    } elseif ($_SESSION['origen_hoteles'] === 'admin') {
        $destino = 'dashboard_admin.php';
    }
}


// Inicializar variables
$nombre = isset($_GET['nombre']) ? trim($_GET['nombre']) : '';
$provincia = isset($_GET['provincia']) ? trim($_GET['provincia']) : '';
$tipo = isset($_GET['tipo']) ? trim($_GET['tipo']) : '';


$sql = "{CALL sp_buscar_hoteles(?, ?, ?)}";
$params = [
    $nombre !== '' ? $nombre : null,
    $provincia !== '' ? $provincia : null,
    $tipo !== '' ? $tipo : null
];

$stmt = sqlsrv_query($conn, $sql, $params);
if ($stmt === false) {
    die("Error al buscar hoteles: " . print_r(sqlsrv_errors(), true));
}


if ($stmt === false) {
    die("Error al buscar hoteles: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar Hoteles</title>
</head>
<body>
    <h2>Buscador de Hoteles</h2>
    <form method="get" action="">
        <label>Nombre del hotel:</label><br>
        <input type="text" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>"><br><br>

        <label>Provincia:</label><br>
        <input type="text" name="provincia" value="<?php echo htmlspecialchars($provincia); ?>"><br><br>

        <label>Tipo de establecimiento:</label><br>
        <input type="text" name="tipo" value="<?php echo htmlspecialchars($tipo); ?>"><br><br>

        <button type="submit">Buscar</button>
    </form>

    <h3>Resultados:</h3>
    <table border="1" cellpadding="6">
        <tr>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Provincia</th>
            <th>Teléfonos</th>
            <th>Email</th>
            <th>Reservar</th>
        </tr>

        <?php while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo htmlspecialchars($fila['NombreHotel']); ?></td>
                <td><?php echo $fila['Tipo']; ?></td>
                <td><?php echo $fila['Provincia']; ?></td>
                <td><?php echo $fila['Telefonos']; ?></td>
                <td><?php echo $fila['Email']; ?></td>
                <td>
                    <?php if (isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'cliente'): ?>
                        <a href="reservas_clientes.php?hotel_id=<?php echo $fila['EstablecimientoID']; ?>">Reservar</a>
                    <?php else: ?>
                        <em>Solo clientes pueden reservar</em>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <br>
    <a href="<?php echo $destino; ?>">← Volver</a>
</body>
</html>

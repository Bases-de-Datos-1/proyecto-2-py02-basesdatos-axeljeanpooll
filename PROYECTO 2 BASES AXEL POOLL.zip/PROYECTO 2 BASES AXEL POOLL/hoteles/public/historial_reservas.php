<?php
session_start();
require_once("../backend/conexion.php");

// Verificar que haya sesión de cliente
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'cliente') {
    header("Location: login_cliente.html");
    exit;
}

// Buscar el ID del cliente logueado
$usuario = $_SESSION['usuario'];
$sql_cliente = "SELECT ClienteID FROM Clientes WHERE Usuario = ?";
$params_cliente = [$usuario];
$stmt_cliente = sqlsrv_query($conn, $sql_cliente, $params_cliente);

if (!$stmt_cliente || !($row_cliente = sqlsrv_fetch_array($stmt_cliente, SQLSRV_FETCH_ASSOC))) {
    die("No se encontró el cliente.");
}
$clienteID = $row_cliente['ClienteID'];

// Consultar el historial de reservaciones
$sql = "
SELECT 
    r.NumeroReserva,
    e.NombreHotel,
    h.NumeroHabitacion,
    r.FechaIngreso,
    r.FechaSalida,
    r.CantidadPersonas,
    r.PoseeVehiculo
FROM Reservaciones r
JOIN Habitaciones h ON r.HabitacionID = h.HabitacionID
JOIN Establecimientos e ON h.EstablecimientoID = e.EstablecimientoID
WHERE r.ClienteID = ?
ORDER BY r.FechaIngreso DESC
";
$params = [$clienteID];
$stmt = sqlsrv_query($conn, $sql, $params);

if (!$stmt) {
    die("Error al obtener las reservaciones: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial de Reservas</title>
</head>
<body>
    <h2>Historial de Reservaciones</h2>

    <table border="1" cellpadding="6">
        <tr>
            <th>N° Reserva</th>
            <th>Hotel</th>
            <th>Habitación</th>
            <th>Ingreso</th>
            <th>Salida</th>
            <th>Personas</th>
            <th>Vehículo</th>
        </tr>
        <?php while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo htmlspecialchars($fila['NumeroReserva']); ?></td>
                <td><?php echo htmlspecialchars($fila['NombreHotel']); ?></td>
                <td><?php echo htmlspecialchars($fila['NumeroHabitacion']); ?></td>
                <td><?php echo $fila['FechaIngreso']->format('Y-m-d'); ?></td>
                <td><?php echo $fila['FechaSalida']->format('Y-m-d'); ?></td>
                <td><?php echo $fila['CantidadPersonas']; ?></td>
                <td><?php echo $fila['PoseeVehiculo'] ? 'Sí' : 'No'; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <br>
    <a href="dashboard_cliente.php">← Volver al inicio</a>
</body>
</html>

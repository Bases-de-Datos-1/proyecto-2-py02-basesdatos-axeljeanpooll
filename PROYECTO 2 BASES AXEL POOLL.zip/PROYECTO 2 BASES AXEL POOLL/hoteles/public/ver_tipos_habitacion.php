<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

// Obtener todos los tipos de habitación
$sql = "{CALL sp_GetTiposHabitacion}";
$resultado = sqlsrv_query($conn, $sql);


if ($resultado === false) {
    die("Error al consultar tipos de habitación: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tipos de Habitación</title>
</head>
<body>
    <h2>Tipos de Habitación Registrados</h2>
    <a href="dashboard_admin.php">← Volver al Dashboard</a><br><br>
    <a href="crear_tipo_habitacion.php">Crear nuevo tipo de habitación</a><br><br>

    <table border="1" cellpadding="6">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Comodidades</th>
            <th>Precio</th>
            <th>Foto</th>
            <th>Acciones</th>
        </tr>

        <?php while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo $fila['TipoHabitacionID']; ?></td>
                <td><?php echo $fila['Nombre']; ?></td>
                <td><?php echo $fila['Descripcion']; ?></td>
                <td><?php echo $fila['Comodidades']; ?></td>
                <td><?php echo number_format($fila['Precio'], 2); ?></td>
                <td><?php echo $fila['Fotos']; ?></td>
                <td>
                    <a href="editar_tipo_habitacion.php?id=<?php echo $fila['TipoHabitacionID']; ?>">Editar</a> |
                    <a href="../backend/eliminar_tipo_habitacion.php?id=<?php echo $fila['TipoHabitacionID']; ?>"
                       onclick="return confirm('¿Está seguro de eliminar este tipo de habitación?');">Eliminar</a>
                </td>
            </tr>
        <?php endwhile; ?>

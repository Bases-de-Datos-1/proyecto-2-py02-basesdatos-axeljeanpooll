<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

$sql = "{CALL sp_listar_establecimientos}";
$resultado = sqlsrv_query($conn, $sql);


if ($resultado === false) {
    die("Error al consultar los establecimientos: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Hoteles Registrados</title>
</head>
<body>
    <h2>Hoteles Registrados</h2>
    <a href="dashboard_admin.php">← Volver al Dashboard</a><br><br>
    <a href="agregar_establecimiento.php">Agregar nuevo hotel</a><br><br>

    <table border="1" cellpadding="6">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Cédula Jurídica</th>
            <th>Tipo</th>
            <th>Provincia</th>
            <th>Cantón</th>
            <th>Distrito</th>
            <th>Teléfonos</th>
            <th>Email</th>
            <th>Acciones</th>
        </tr>

        <?php while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo $fila['EstablecimientoID']; ?></td>
                <td><?php echo htmlspecialchars($fila['NombreHotel']); ?></td>
                <td><?php echo $fila['CedulaJuridica']; ?></td>
                <td><?php echo $fila['Tipo']; ?></td>
                <td><?php echo $fila['Provincia']; ?></td>
                <td><?php echo $fila['Canton']; ?></td>
                <td><?php echo $fila['Distrito']; ?></td>
                <td><?php echo $fila['Telefonos']; ?></td>
                <td><?php echo $fila['Email']; ?></td>
                <td>
                    <a href="editar_establecimiento.php?id=<?php echo $fila['EstablecimientoID']; ?>">Editar</a>
                    <a href="../backend/eliminar_establecimiento.php?id=<?php echo $fila['EstablecimientoID']; ?>"
                       onclick="return confirm('¿Está seguro que desea eliminar este hotel?');">Eliminar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

// Llamar al procedimiento almacenado con filtros nulos
$sql = "{CALL sp_GetClientes(?, ?, ?)}";
$params = [null, null, null];
$stmt = sqlsrv_query($conn, $sql, $params);


if ($stmt === false) {
    die("Error al obtener clientes: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Clientes</title>
</head>

<?php if (isset($_GET['error'])): ?>
    <p style="color: red;"><?php echo htmlspecialchars($_GET['error']); ?></p>
<?php endif; ?>
<?php if (isset($_GET['mensaje'])): ?>
    <p style="color: green;"><?php echo htmlspecialchars($_GET['mensaje']); ?></p>
<?php endif; ?>

<body>
    <h2>Clientes Registrados</h2>
    <a href="dashboard_admin.php">← Volver al dashboard</a>
    <br><br>

    <table border="1" cellpadding="6">
        <tr>
            <th>Nombre completo</th>
            <th>Cédula</th>
            <th>Usuario</th>
            <th>País</th>
            <th>Email</th>
            <th>Acción</th>
        </tr>
        <?php while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) : ?>
            <tr>
                <td>
                    <?php echo htmlspecialchars($fila['Nombre'] . ' ' . $fila['PrimerApellido'] . ' ' . $fila['SegundoApellido']); ?>
                </td>
                <td><?php echo htmlspecialchars($fila['Cedula']); ?></td>
                <td><?php echo htmlspecialchars($fila['Usuario']); ?></td>
                <td><?php echo htmlspecialchars($fila['PaisResidencia']); ?></td>
                <td><?php echo htmlspecialchars($fila['Email']); ?></td>
                <td>
                    <a href="editar_cliente.php?id=<?php echo $fila['ClienteID']; ?>">Editar</a> |
                    <a href="../backend/eliminar_cliente.php?id=<?php echo $fila['ClienteID']; ?>"
                       onclick="return confirm('¿Está seguro de eliminar este cliente?');">Eliminar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

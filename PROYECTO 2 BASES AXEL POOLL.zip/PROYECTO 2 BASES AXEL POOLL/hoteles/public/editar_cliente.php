<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

// Obtener ID del cliente
$clienteID = $_GET['id'] ?? null;
if (!$clienteID) {
    die("ID de cliente no proporcionado.");
}

// Obtener datos del cliente
$sql = "SELECT * FROM vw_Clientes WHERE ClienteID = ?";
$params = [$clienteID];
$stmt = sqlsrv_query($conn, $sql, $params);


if ($stmt === false || !($cliente = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))) {
    die("Cliente no encontrado.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Cliente</title>
</head>
<body>
    <h2>Editar Cliente</h2>
    <a href="ver_clientes.php">← Volver a la lista de clientes</a>
    <br><br>

    <form action="../backend/procesar_editar_cliente.php" method="post">
        <input type="hidden" name="cliente_id" value="<?php echo $cliente['ClienteID']; ?>">

        <label>Nombre:</label><br>
        <input type="text" name="nombre" value="<?php echo htmlspecialchars($cliente['Nombre']); ?>" required><br><br>

        <label>Primer apellido:</label><br>
        <input type="text" name="apellido1" value="<?php echo htmlspecialchars($cliente['PrimerApellido']); ?>" required><br><br>

        <label>Segundo apellido:</label><br>
        <input type="text" name="apellido2" value="<?php echo htmlspecialchars($cliente['SegundoApellido']); ?>"><br><br>

        <label>País:</label><br>
        <input type="text" name="pais" value="<?php echo htmlspecialchars($cliente['PaisResidencia']); ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo htmlspecialchars($cliente['Email']); ?>" required><br><br>

        <label>Usuario:</label><br>
        <input type="text" name="usuario" value="<?php echo htmlspecialchars($cliente['Usuario']); ?>" required><br><br>

        <label>Provincia:</label><br>
        <input type="text" name="provincia" required><br><br>

        <label>Cantón:</label><br>
        <input type="text" name="canton" required><br><br>

        <label>Distrito:</label><br>
        <input type="text" name="distrito" required><br><br>

        <label>Teléfono 1:</label><br>
        <input type="text" name="telefono1" required><br><br>

        <label>Teléfono 2 (opcional):</label><br>
        <input type="text" name="telefono2"><br><br>

        <label>Teléfono 3 (opcional):</label><br>
        <input type="text" name="telefono3"><br><br>

        <label>Clave (dejar en blanco si no desea cambiarla):</label><br>
        <input type="password" name="clave"><br><br>

        <button type="submit">Guardar cambios</button>
    </form>
</body>
</html>

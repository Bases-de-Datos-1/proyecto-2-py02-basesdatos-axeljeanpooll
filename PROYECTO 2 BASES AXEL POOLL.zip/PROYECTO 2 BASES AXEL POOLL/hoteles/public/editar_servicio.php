<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

if (!isset($_GET['id'])) {
    die("ID de servicio no especificado.");
}

$id = $_GET['id'];

$sql = "SELECT * FROM ActividadesRecreacion WHERE ActividadID = ?";
$params = array($id);
$stmt = sqlsrv_query($conn, $sql, $params);
$servicio = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if (!$servicio) {
    die("Actividad no encontrada.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Actividad</title>
</head>
<body>
    <h2>Editar Actividad Recreativa</h2>
    <form action="../backend/procesar_edicion_servicio.php" method="post">
        <input type="hidden" name="actividad_id" value="<?php echo $servicio['ActividadID']; ?>">

        <label>Establecimiento ID:</label><br>
        <input type="text" value="<?php echo $servicio['EstablecimientoID']; ?>" readonly><br><br>

        <label>Nombre Empresa:</label><br>
        <input type="text" name="nombre_empresa" value="<?php echo $servicio['NombreEmpresa']; ?>" required><br><br>

        <label>Cédula Jurídica:</label><br>
        <input type="text" name="cedula_juridica" value="<?php echo $servicio['CedulaJuridica']; ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo $servicio['Email']; ?>" required><br><br>

        <label>Teléfono:</label><br>
        <input type="text" name="telefono" value="<?php echo $servicio['Telefono']; ?>" required><br><br>

        <label>Nombre Contacto:</label><br>
        <input type="text" name="nombre_contacto" value="<?php echo $servicio['NombreContacto']; ?>" required><br><br>

        <label>Provincia:</label><br>
        <input type="text" name="provincia" value="<?php echo $servicio['Provincia']; ?>" required><br><br>

        <label>Cantón:</label><br>
        <input type="text" name="canton" value="<?php echo $servicio['Canton']; ?>" required><br><br>

        <label>Distrito:</label><br>
        <input type="text" name="distrito" value="<?php echo $servicio['Distrito']; ?>" required><br><br>

        <label>Señas:</label><br>
        <input type="text" name="senas" value="<?php echo $servicio['Senas']; ?>" required><br><br>

        <label>Tipo Actividad:</label><br>
        <input type="text" name="tipo_actividad" value="<?php echo $servicio['TipoActividad']; ?>" required><br><br>

        <label>Descripción:</label><br>
        <input type="text" name="descripcion" value="<?php echo $servicio['Descripcion']; ?>"><br><br>

        <label>Precio:</label><br>
        <input type="number" name="precio" step="0.01" value="<?php echo $servicio['Precio']; ?>" required><br><br>

        <button type="submit">Guardar Cambios</button>
    </form>
</body>
</html>

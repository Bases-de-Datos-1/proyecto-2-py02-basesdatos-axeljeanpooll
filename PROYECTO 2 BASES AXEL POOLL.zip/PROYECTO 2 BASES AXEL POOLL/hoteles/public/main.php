<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Página Principal - Gestión Hotelera</title>
    <link rel="stylesheet" href="estilos.css"> <!--hoja de estilos -->
</head>
<body>
    <h1>Bienvenido al Sistema de Gestión Hotelera</h1>

    <div class="menu-opciones">
        <ul>
            <li><a href="registro_cliente.php">Registrarse como nuevo Cliente</a></li>
            <li><a href="dashboard_cliente.php">Iniciar sesión como Cliente</a></li>
            <li><a href="dashboard_admin.php">Iniciar sesión como Administrador</a></li>
            <li><a href="ir_a_hoteles_desde_main.php">Ver y Buscar Hoteles Disponibles</a></li>
        </ul>
    </div>
</body>
</html>

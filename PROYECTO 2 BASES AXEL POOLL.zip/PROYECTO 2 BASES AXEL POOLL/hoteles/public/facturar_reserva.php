<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once("../backend/conexion.php");

// Verificar si se envió una reserva por GET
$reservacion_id = isset($_GET['reservacion_id']) ? (int)$_GET['reservacion_id'] : 0;

$datos_reserva = null;

if ($reservacion_id > 0) {
    $sql = "SELECT r.ReservacionID, r.FechaIngreso, r.FechaSalida, r.CantidadPersonas,
                   h.NumeroHabitacion, t.Nombre AS TipoNombre, t.Precio
            FROM Reservaciones r
            JOIN Habitaciones h ON r.HabitacionID = h.HabitacionID
            JOIN TiposHabitacion t ON h.TipoHabitacionID = t.TipoHabitacionID
            WHERE r.ReservacionID = ?";
    $params = [$reservacion_id];
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        echo "<p style='color:red;'>Error en la consulta:</p>";
        print_r(sqlsrv_errors());
    } elseif ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $datos_reserva = $fila;
        $fecha1 = new DateTime($fila['FechaIngreso']->format('Y-m-d'));
        $fecha2 = new DateTime($fila['FechaSalida']->format('Y-m-d'));
        $dias = $fecha1->diff($fecha2)->days;
        if ($dias < 1) $dias = 1;
        $importe_total = $dias * $fila['Precio'];
    } else {
        echo "<p style='color:red;'>No se encontró la reservación especificada (ID: $reservacion_id).</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Facturar Reserva</title>
</head>
<body>
    <h2>Facturar Reserva</h2>

    <form method="get" action="">
        <label for="reservacion_id">Ingrese el ID de la reservación:</label>
        <input type="number" name="reservacion_id" required>
        <button type="submit">Buscar</button>
    </form>

    <?php if ($datos_reserva): ?>
        <h3>Datos de la Reservación</h3>
        <ul>
            <li>Habitación: <?php echo $datos_reserva['NumeroHabitacion']; ?></li>
            <li>Tipo: <?php echo $datos_reserva['TipoNombre']; ?></li>
            <li>Ingreso: <?php echo $datos_reserva['FechaIngreso']->format('Y-m-d'); ?></li>
            <li>Salida: <?php echo $datos_reserva['FechaSalida']->format('Y-m-d'); ?></li>
            <li>Noches: <?php echo $dias; ?></li>
            <li>Precio por noche: ₡<?php echo number_format($datos_reserva['Precio'], 2); ?></li>
            <li><strong>Total: ₡<?php echo number_format($importe_total, 2); ?></strong></li>
        </ul>

        <form method="post" action="../backend/procesar_factura.php">
            <input type="hidden" name="reservacion_id" value="<?php echo $reservacion_id; ?>">

            <label>Método de pago:</label>
            <select name="metodo_pago" required>
                <option value="efectivo">Efectivo</option>
                <option value="tarjeta de crédito">Tarjeta de crédito</option>
            </select><br><br>

            <button type="submit">Confirmar Factura</button>
        </form>
    <?php endif; ?>

    <br><a href="dashboard_admin.php">← Volver al inicio</a>
</body>
</html>

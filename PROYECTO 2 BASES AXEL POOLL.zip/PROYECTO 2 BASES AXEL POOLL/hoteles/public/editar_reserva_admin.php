<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

// Validar que viene el ID por GET
if (!isset($_GET['id'])) {
    die("ID de reserva no especificado.");
}

$id = intval($_GET['id']);

// Obtener la información de la reserva
$sql = "
SELECT 
    r.ReservacionID,
    r.NumeroReserva,
    r.HabitacionID,
    r.FechaIngreso,
    r.FechaSalida,
    r.CantidadPersonas,
    r.PoseeVehiculo
FROM Reservaciones r
WHERE r.ReservacionID = ?
";

$params = [$id];
$stmt = sqlsrv_query($conn, $sql, $params);
if ($stmt === false) {
    die("Error en la consulta: " . print_r(sqlsrv_errors(), true));
}

$reserva = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
if (!$reserva) {
    die("Reserva no encontrada.");
}

// Obtener lista de habitaciones para el selector
$sqlHab = "
SELECT h.HabitacionID, h.NumeroHabitacion, t.Nombre AS Tipo
FROM Habitaciones h
JOIN TiposHabitacion t ON h.TipoHabitacionID = t.TipoHabitacionID
";
$resHabitaciones = sqlsrv_query($conn, $sqlHab);
if ($resHabitaciones === false) {
    die("Error al obtener habitaciones: " . print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Reserva</title>
</head>
<body>
    <h2>Editar Reserva</h2>
    <form action="../backend/procesar_edicion_reserva.php" method="post">
        <input type="hidden" name="reservacion_id" value="<?php echo $reserva['ReservacionID']; ?>">

        <label>Habitación:</label><br>
        <select name="habitacion_id" required>
            <?php while ($hab = sqlsrv_fetch_array($resHabitaciones, SQLSRV_FETCH_ASSOC)) : ?>
                <option value="<?php echo $hab['HabitacionID']; ?>"
                    <?php if ($hab['HabitacionID'] == $reserva['HabitacionID']) echo "selected"; ?>>
                    <?php echo $hab['NumeroHabitacion'] . " - " . $hab['Tipo']; ?>
                </option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Fecha Ingreso:</label><br>
        <input type="date" name="fecha_ingreso" value="<?php echo $reserva['FechaIngreso']->format('Y-m-d'); ?>" required><br><br>

        <label>Fecha Salida:</label><br>
        <input type="date" name="fecha_salida" value="<?php echo $reserva['FechaSalida']->format('Y-m-d'); ?>" required><br><br>

        <label>Cantidad de personas:</label><br>
        <input type="number" name="cantidad_personas" min="1" value="<?php echo $reserva['CantidadPersonas']; ?>" required><br><br>

        <label>¿Posee vehículo?</label><br>
        <select name="posee_vehiculo" required>
            <option value="0" <?php if (!$reserva['PoseeVehiculo']) echo "selected"; ?>>No</option>
            <option value="1" <?php if ($reserva['PoseeVehiculo']) echo "selected"; ?>>Sí</option>
        </select><br><br>

        <button type="submit">Guardar Cambios</button>
    </form>
</body>
</html>

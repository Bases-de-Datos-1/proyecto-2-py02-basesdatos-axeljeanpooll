<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once("../backend/conexion.php");

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "{CALL sp_obtener_establecimiento_por_id(?)}";
$stmt = sqlsrv_query($conn, $sql, [$id]);

if ($stmt === false || !($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))) {
    die("Error: Establecimiento no encontrado.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Establecimiento</title>
</head>
<body>
    <h2>Editar Establecimiento</h2>
    <form action="../backend/procesar_edicion_establecimiento.php" method="post">
        <input type="hidden" name="id" value="<?php echo $row['EstablecimientoID']; ?>">
        
        <label>Nombre Hotel:</label><br>
        <input type="text" name="nombre" value="<?php echo $row['NombreHotel']; ?>" required><br><br>

        <label>Cédula Jurídica:</label><br>
        <input type="text" name="cedula" value="<?php echo $row['CedulaJuridica']; ?>" required><br><br>

        <label>Tipo:</label><br>
        <input type="text" name="tipo" value="<?php echo $row['Tipo']; ?>" required><br><br>

        <label>Provincia:</label><br>
        <input type="text" name="provincia" value="<?php echo $row['Provincia']; ?>" required><br><br>

        <label>Cantón:</label><br>
        <input type="text" name="canton" value="<?php echo $row['Canton']; ?>" required><br><br>

        <label>Distrito:</label><br>
        <input type="text" name="distrito" value="<?php echo $row['Distrito']; ?>" required><br><br>

        <label>Barrio:</label><br>
        <input type="text" name="barrio" value="<?php echo $row['Barrio']; ?>" required><br><br>

        <label>Señas:</label><br>
        <textarea name="senas" required><?php echo $row['Senas']; ?></textarea><br><br>

        <label>Referencia:</label><br>
        <input type="text" name="referencia" value="<?php echo $row['Referencia']; ?>"><br><br>

        <label>Teléfonos:</label><br>
        <input type="text" name="telefonos" value="<?php echo $row['Telefonos']; ?>"><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo $row['Email']; ?>"><br><br>

        <label>Sitio Web:</label><br>
        <input type="text" name="url" value="<?php echo $row['URLSitioWeb']; ?>"><br><br>

        <label>Facebook:</label><br>
        <input type="text" name="facebook" value="<?php echo $row['Facebook']; ?>"><br><br>

        <label>Instagram:</label><br>
        <input type="text" name="instagram" value="<?php echo $row['Instagram']; ?>"><br><br>

        <label>YouTube:</label><br>
        <input type="text" name="youtube" value="<?php echo $row['YouTube']; ?>"><br><br>

        <label>TikTok:</label><br>
        <input type="text" name="tiktok" value="<?php echo $row['TikTok']; ?>"><br><br>

        <label>Threads:</label><br>
        <input type="text" name="threads" value="<?php echo $row['Threads']; ?>"><br><br>

        <label>X:</label><br>
        <input type="text" name="x" value="<?php echo $row['X_Red']; ?>"><br><br>

        <label>Lista de Servicios:</label><br>
        <input type="text" name="servicios" value="<?php echo $row['ListaServicios']; ?>"><br><br>

        <button type="submit">Guardar Cambios</button>
    </form>
</body>
</html>

<?php
require_once("conexion.php");

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$cedula = $_POST['cedula'];
$tipo = $_POST['tipo'];
$provincia = $_POST['provincia'];
$canton = $_POST['canton'];
$distrito = $_POST['distrito'];
$barrio = $_POST['barrio'];
$senas = $_POST['senas'];
$referencia = $_POST['referencia'];
$telefonos = $_POST['telefonos'];
$email = $_POST['email'];
$sitio = $_POST['url'];
$facebook = $_POST['facebook'];
$instagram = $_POST['instagram'];
$youtube = $_POST['youtube'];
$tiktok = $_POST['tiktok'];
$threads = $_POST['threads'];
$x = $_POST['x'];
$servicios = $_POST['servicios'];

$sql = "{CALL sp_actualizar_establecimiento(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

$params = [
    $id, $nombre, $cedula, $tipo, $provincia, $canton, $distrito, $barrio, $senas,
    $referencia, $telefonos, $email, $sitio, $facebook, $instagram, $youtube,
    $tiktok, $threads, $x, $servicios
];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt) {
    header("Location: ../public/ver_establecimientos.php");
} else {
    echo "Error al actualizar: ";
    print_r(sqlsrv_errors());
}

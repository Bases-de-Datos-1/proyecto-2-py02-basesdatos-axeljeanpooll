<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

$numero = $_POST['numero'] ?? '';
$establecimiento_id = $_POST['establecimiento_id'] ?? '';
$tipo_id = $_POST['tipo_id'] ?? '';

// Validación básica
if ($numero === '' || $establecimiento_id === '' || $tipo_id === '') {
    die("Todos los campos son obligatorios.");
}

// Llamar al procedimiento almacenado
$sql = "{CALL sp_CreateHabitacion(?, ?, ?)}";
$params = [$numero, $establecimiento_id, $tipo_id];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt) {
    header("Location: ../public/ver_habitaciones.php");
    exit;
} else {
    echo "Error al agregar habitación: ";
    print_r(sqlsrv_errors(), true);
}

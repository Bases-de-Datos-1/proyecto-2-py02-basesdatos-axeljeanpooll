<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

// Recoger datos del formulario
$nombre      = $_POST['nombre'] ?? '';
$cedula      = $_POST['cedula'] ?? '';
$tipo        = $_POST['tipo'] ?? '';
$provincia   = $_POST['provincia'] ?? '';
$canton      = $_POST['canton'] ?? '';
$distrito    = $_POST['distrito'] ?? '';
$barrio      = $_POST['barrio'] ?? '';
$senas       = $_POST['senas'] ?? '';
$referencia  = $_POST['referencia'] ?? '';
$telefonos   = $_POST['telefonos'] ?? '';
$email       = $_POST['email'] ?? '';
$sitio       = $_POST['sitio'] ?? '';
$facebook    = $_POST['facebook'] ?? '';
$instagram   = $_POST['instagram'] ?? '';
$youtube     = $_POST['youtube'] ?? '';
$tiktok      = $_POST['tiktok'] ?? '';
$threads     = $_POST['threads'] ?? '';
$x           = $_POST['x'] ?? '';
$servicios   = $_POST['servicios'] ?? '';

// Consulta SQL
$sql = "{CALL sp_insertar_establecimiento(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

$params = [
    $nombre, $cedula, $tipo, $provincia, $canton, $distrito, $barrio, $senas,
    $referencia, $telefonos, $email, $sitio, $facebook, $instagram, $youtube,
    $tiktok, $threads, $x, $servicios
];

$stmt = sqlsrv_query($conn, $sql, $params);

// Verificar si la consulta se ejecutó correctamente
if ($stmt === false) {
    die("Error al agregar el establecimiento: " . print_r(sqlsrv_errors(), true));
}

// Redireccionar al listado
header("Location: ../public/ver_establecimientos.php");
exit;

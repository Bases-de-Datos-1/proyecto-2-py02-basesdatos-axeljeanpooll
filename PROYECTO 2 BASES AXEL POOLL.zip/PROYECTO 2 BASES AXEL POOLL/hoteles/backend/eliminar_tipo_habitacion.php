<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

if (!isset($_GET['id'])) {
    die("ID no proporcionado.");
}

$id = intval($_GET['id']);

// Comprobar si hay habitaciones asociadas antes de eliminar
$checkSql = "SELECT COUNT(*) AS total FROM Habitaciones WHERE TipoHabitacionID = ?";
$checkStmt = sqlsrv_query($conn, $checkSql, [$id]);
$checkRow = sqlsrv_fetch_array($checkStmt, SQLSRV_FETCH_ASSOC);

if ($checkRow['total'] > 0) {
    die("No se puede eliminar este tipo de habitación porque hay habitaciones asociadas.");
}

// Eliminar si no hay dependencias
$sql = "{CALL sp_DeleteTipoHabitacion(?)}";
$stmt = sqlsrv_query($conn, $sql, [$id]);

if ($stmt === false) {
    die("Error al eliminar: " . print_r(sqlsrv_errors(), true));
}

header("Location: ../public/ver_tipos_habitacion.php");
exit;

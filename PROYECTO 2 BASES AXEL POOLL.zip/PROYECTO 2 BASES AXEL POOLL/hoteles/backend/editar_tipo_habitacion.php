<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

$id = intval($_POST['id']);
$nombre = $_POST['nombre'] ?? '';
$descripcion = $_POST['descripcion'] ?? '';
$comodidades = $_POST['comodidades'] ?? '';
$precio = $_POST['precio'] ?? 0;
$foto = $_POST['foto'] ?? '';

// Llamar al procedimiento
$sql = "{CALL sp_UpdateTipoHabitacion(?, ?, ?, ?, ?, ?)}";
$params = [$id, $nombre, $descripcion, $comodidades, $precio, $foto];


$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die("Error al actualizar el tipo de habitación: " . print_r(sqlsrv_errors(), true));
}

header("Location: ../public/ver_tipos_habitacion.php");
exit;

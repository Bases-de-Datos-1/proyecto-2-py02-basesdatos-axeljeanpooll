<?php
session_start();
require_once("conexion.php");

$usuario = $_POST['usuario'] ?? '';
$clave = $_POST['clave'] ?? '';

echo "Conexión exitosa a la base de datos.";

$sql = "SELECT * FROM Administradores WHERE Usuario = ? AND Clave = ?";
$params = array($usuario, $clave);
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt && sqlsrv_fetch($stmt)) {
    $_SESSION['usuario'] = $usuario;
    $_SESSION['tipo'] = 'admin';
    header("Location: ../public/dashboard_admin.php");
    exit;
} else {
    echo "<br>Usuario o clave incorrectos.";
}

?>

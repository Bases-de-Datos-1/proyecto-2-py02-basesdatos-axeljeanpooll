<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

// Obtener datos del formulario
$clienteID       = $_POST['cliente_id'] ?? null;
$nombre          = trim($_POST['nombre'] ?? '');
$apellido1       = trim($_POST['apellido1'] ?? '');
$apellido2       = trim($_POST['apellido2'] ?? '');
$provincia       = trim($_POST['provincia'] ?? '');
$canton          = trim($_POST['canton'] ?? '');
$distrito        = trim($_POST['distrito'] ?? '');
$telefono1       = trim($_POST['telefono1'] ?? '');
$telefono2       = trim($_POST['telefono2'] ?? '');
$telefono3       = trim($_POST['telefono3'] ?? '');
$email           = trim($_POST['email'] ?? '');

// Validación básica
if (!$clienteID || !$nombre || !$apellido1 || !$provincia || !$canton || !$distrito || !$telefono1 || !$email) {
    die("Faltan datos obligatorios.");
}

// Llamada al procedimiento
$sql = "{CALL sp_UpdateCliente(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
$params = [
    $clienteID,
    $nombre,
    $apellido1,
    $apellido2 !== '' ? $apellido2 : null,
    $provincia,
    $canton,
    $distrito,
    $telefono1,
    $telefono2 !== '' ? $telefono2 : null,
    $telefono3 !== '' ? $telefono3 : null,
    $email
];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt) {
    header("Location: ../public/ver_clientes.php?mensaje=Cliente actualizado correctamente");
    exit;
} else {
    echo "Error al actualizar el cliente:<br>";
    if (($errors = sqlsrv_errors()) != null) {
        foreach ($errors as $error) {
            echo "SQLSTATE: " . $error['SQLSTATE'] . "<br>";
            echo "Code: " . $error['code'] . "<br>";
            echo "Message: " . $error['message'] . "<br>";
        }
    }
}

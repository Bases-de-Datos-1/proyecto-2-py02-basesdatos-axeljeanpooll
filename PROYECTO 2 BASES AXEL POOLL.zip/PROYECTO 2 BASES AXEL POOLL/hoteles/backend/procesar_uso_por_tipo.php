<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit();
}

include("conexion.php");

// Recoger parámetros del formulario
$desde = !empty($_POST['desde']) ? $_POST['desde'] : null;
$hasta = !empty($_POST['hasta']) ? $_POST['hasta'] : null;
$tipos = isset($_POST['tipos']) && $_POST['tipos'] !== '' ? $_POST['tipos'] : null;

// Preparar llamada al procedimiento
$sql = "{CALL sp_ReportUsoPorTipo(?, ?, ?)}";
$params = array($desde, $hasta, $tipos);

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Mostrar tabla
echo "<h2>Resultado del Reporte</h2>";
echo "<table border='1'>
<tr>
    <th>Tipo de Habitación</th>
    <th>N° Reservas</th>
    <th>Total Noches</th>
</tr>";

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $row['TipoHabitacion'] . "</td>";
    echo "<td>" . $row['NumReservas'] . "</td>";
    echo "<td>" . $row['TotalNoches'] . "</td>";
    echo "</tr>";
}

echo "</table>";
echo "<br><a href='../public/dashboard.php'>Volver al Dashboard</a>";
?>

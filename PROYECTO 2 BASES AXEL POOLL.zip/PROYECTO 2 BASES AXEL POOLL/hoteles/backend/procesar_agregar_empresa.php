<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit();
}

require_once("conexion.php");

// Obtener datos del formulario
$establecimiento_id = $_POST['establecimiento_id'] ?? null;
$nombre_empresa     = trim($_POST['nombre_empresa'] ?? '');
$cedula_juridica    = trim($_POST['cedula_juridica'] ?? '');
$email              = trim($_POST['email'] ?? '');
$telefono           = trim($_POST['telefono'] ?? '');
$nombre_contacto    = trim($_POST['nombre_contacto'] ?? '');
$provincia          = trim($_POST['provincia'] ?? '');
$canton             = trim($_POST['canton'] ?? '');
$distrito           = trim($_POST['distrito'] ?? '');
$senas              = trim($_POST['senas'] ?? '');
$tipo_actividad     = trim($_POST['tipo_actividad'] ?? '');
$descripcion        = trim($_POST['descripcion'] ?? '');
$precio             = $_POST['precio'] ?? null;

// Validar campos obligatorios
if (!$establecimiento_id || !$nombre_empresa || !$cedula_juridica || !$email || !$telefono ||
    !$nombre_contacto || !$provincia || !$canton || !$distrito || !$senas || !$tipo_actividad || $precio === null) {
    
    header("Location: ../public/agregar_empresa.php?error=Faltan datos obligatorios");
    exit();
}

// Llamada al procedimiento almacenado
$sql = "{CALL sp_CreateActividad(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

$params = [
    $establecimiento_id,
    $nombre_empresa,
    $cedula_juridica,
    $email,
    $telefono,
    $nombre_contacto,
    $provincia,
    $canton,
    $distrito,
    $senas,
    $tipo_actividad,
    $descripcion ?: null,
    $precio
];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt) {
    header("Location: ../public/ver_empresas.php?mensaje=Empresa agregada correctamente");
    exit();
} else {
    echo "Conexión exitosa a la base de datos.<br>";
    echo "Error al agregar empresa:<br>";
    print_r(sqlsrv_errors());
    echo "<br><a href='../public/agregar_empresa.php'>Volver</a>";
}
?>

<?php
session_start();

// Verificar que el usuario este autenticado y sea cliente o admin
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'cliente') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

// Obtener datos del formulario
$habitacionID = $_POST['habitacion_id'] ?? null;
$fechaIngreso = $_POST['fecha_ingreso'] ?? null;
$fechaSalida = $_POST['fecha_salida'] ?? null;
$cantidadPersonas = $_POST['cantidad_personas'] ?? null;
$poseeVehiculo = $_POST['posee_vehiculo'] ?? 0;

// Validar que todos los campos estén presentes
if (!$habitacionID || !$fechaIngreso || !$fechaSalida || !$cantidadPersonas) {
    die("Faltan datos para procesar la reserva.");
}

// Obtener el usuario actual y su tipo
$usuario = $_SESSION['usuario'];
$tipo = $_SESSION['tipo'];

// Buscar el ID correspondiente dependiendo del tipo de usuario
if ($tipo === 'cliente') {
    $sqlID = "SELECT ClienteID AS ID FROM Clientes WHERE Usuario = ?";
} elseif ($tipo === 'admin') {
    $sqlID = "SELECT AdministradorID AS ID FROM Administradores WHERE Usuario = ?";
} else {
    die("Tipo de usuario no permitido.");
}

$paramsID = [$usuario];
$stmtID = sqlsrv_query($conn, $sqlID, $paramsID);
if (!$stmtID || !($row = sqlsrv_fetch_array($stmtID, SQLSRV_FETCH_ASSOC))) {
    die("No se encontró el usuario.");
}
$usuarioID = $row['ID'];

// Generar numero de reserva aleatorio
$numeroReserva = 'RES-' . strtoupper(uniqid());

// Insertar la reserva
$sqlInsert = "INSERT INTO Reservaciones (NumeroReserva, ClienteID, HabitacionID, FechaIngreso, FechaSalida, CantidadPersonas, PoseeVehiculo)
              VALUES (?, ?, ?, ?, ?, ?, ?)";

$paramsInsert = [
    $numeroReserva,
    $usuarioID,
    $habitacionID,
    $fechaIngreso,
    $fechaSalida,
    $cantidadPersonas,
    $poseeVehiculo
];

$stmtInsert = sqlsrv_query($conn, $sqlInsert, $paramsInsert);

if ($stmtInsert) {
    echo "Reserva realizada exitosamente. Número de reserva: $numeroReserva";
} else {
    echo "Error al registrar la reserva: ";
    print_r(sqlsrv_errors());
}
?>

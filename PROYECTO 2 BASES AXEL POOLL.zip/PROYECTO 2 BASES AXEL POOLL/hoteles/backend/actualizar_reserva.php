<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

// Validar que llegan todos los campos necesarios
if (
    isset($_POST['reservacion_id']) &&
    isset($_POST['habitacion_id']) &&
    isset($_POST['fecha_ingreso']) &&
    isset($_POST['fecha_salida']) &&
    isset($_POST['cantidad_personas']) &&
    isset($_POST['posee_vehiculo'])
) {
    $id = $_POST['reservacion_id'];
    $habitacion_id = $_POST['habitacion_id'];
    $fecha_ingreso = $_POST['fecha_ingreso'];
    $fecha_salida = $_POST['fecha_salida'];
    $cantidad = $_POST['cantidad_personas'];
    $vehiculo = $_POST['posee_vehiculo'];

    $sql = "UPDATE Reservaciones 
            SET HabitacionID = ?, FechaIngreso = ?, FechaSalida = ?, CantidadPersonas = ?, PoseeVehiculo = ?
            WHERE ReservacionID = ?";

    $params = [$habitacion_id, $fecha_ingreso, $fecha_salida, $cantidad, $vehiculo, $id];
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        die("Error al actualizar: " . print_r(sqlsrv_errors(), true));
    }

    // Redirigir de vuelta a la lista de reservas
    header("Location: ../public/ver_reservas_admin.php");
    exit;

} else {
    echo "Faltan datos del formulario.";
}

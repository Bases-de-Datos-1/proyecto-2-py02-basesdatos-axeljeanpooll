<?php
require_once("conexion.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = intval($_POST["reservacion_id"]);
    $habitacion_id = intval($_POST["habitacion_id"]);
    $fecha_ingreso = $_POST["fecha_ingreso"];
    $fecha_salida = $_POST["fecha_salida"];
    $cantidad = intval($_POST["cantidad_personas"]);
    $vehiculo = intval($_POST["posee_vehiculo"]);

    $sql = "
        UPDATE Reservaciones
        SET 
            HabitacionID = ?,
            FechaIngreso = ?,
            FechaSalida = ?,
            CantidadPersonas = ?,
            PoseeVehiculo = ?
        WHERE ReservacionID = ?
    ";

    $params = [$habitacion_id, $fecha_ingreso, $fecha_salida, $cantidad, $vehiculo, $id];
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        die("Error al actualizar reserva: " . print_r(sqlsrv_errors(), true));
    }

    header("Location: ../public/ver_reservas_admin.php");
    exit;
} else {
    echo "Método inválido.";
}

<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

$clienteID = $_GET['id'] ?? null;

if (!$clienteID || !is_numeric($clienteID)) {
    header("Location: ../public/ver_clientes.php?error=ID de cliente no válido.");
    exit;
}

// Verificar si el cliente tiene reservas
$sqlCheck = "SELECT COUNT(*) AS total FROM Reservaciones WHERE ClienteID = ?";
$paramsCheck = [$clienteID];
$stmtCheck = sqlsrv_query($conn, $sqlCheck, $paramsCheck);

if ($stmtCheck === false) {
    header("Location: ../public/ver_clientes.php?error=Error al verificar reservas.");
    exit;
}

$row = sqlsrv_fetch_array($stmtCheck, SQLSRV_FETCH_ASSOC);
if ($row && $row['total'] > 0) {
    header("Location: ../public/ver_clientes.php?error=No se puede eliminar el cliente porque tiene reservas asociadas.");
    exit;
}

// Si no tiene reservas, proceder con eliminación usando procedimiento
$sqlDelete = "{CALL sp_DeleteCliente(?)}";
$paramsDelete = [$clienteID];
$stmtDelete = sqlsrv_query($conn, $sqlDelete, $paramsDelete);

if ($stmtDelete) {
    header("Location: ../public/ver_clientes.php?mensaje=Cliente eliminado correctamente");
    exit;
} else {
    echo "Error al eliminar el cliente:<br>";
    if (($errors = sqlsrv_errors()) != null) {
        foreach ($errors as $error) {
            echo "SQLSTATE: " . $error['SQLSTATE'] . "<br>";
            echo "Code: " . $error['code'] . "<br>";
            echo "Message: " . $error['message'] . "<br>";
        }
    }
}

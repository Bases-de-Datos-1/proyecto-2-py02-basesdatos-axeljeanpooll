<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit();
}

require_once("conexion.php");

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    echo "ID de empresa no válido.";
    exit();
}

// Llamar al procedimiento almacenado
$sql = "{CALL sp_DeleteActividad(?)}";
$params = [$id];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    echo "Error al eliminar la empresa:<br>";
    print_r(sqlsrv_errors());
    exit();
}

header("Location: ../public/ver_empresas.php?mensaje=Empresa eliminada correctamente");
exit();

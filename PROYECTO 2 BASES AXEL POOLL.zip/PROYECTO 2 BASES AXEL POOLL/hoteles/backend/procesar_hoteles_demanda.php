<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit();
}

include("conexion.php");

// Obtener filtros
$desde = !empty($_POST['desde']) ? $_POST['desde'] : null;
$hasta = !empty($_POST['hasta']) ? $_POST['hasta'] : null;
$provincia = isset($_POST['provincia']) && $_POST['provincia'] !== '' ? $_POST['provincia'] : null;
$canton = isset($_POST['canton']) && $_POST['canton'] !== '' ? $_POST['canton'] : null;

// Ejecutar el procedimiento
$sql = "{CALL sp_ReportHotelesDemanda(?, ?, ?, ?)}";
$params = array($desde, $hasta, $provincia, $canton);

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Mostrar resultados
header('Content-Type: text/html; charset=utf-8'); // Esto es para asegurar que acepte tildes y caracteres especiales
echo "<h2>Resultado del Reporte</h2>";
echo "<table border='1'>
<tr>
    <th>Establecimiento ID</th>
    <th>Nombre Hotel</th>
    <th>Provincia</th>
    <th>Cantón</th>
    <th>N° Reservas</th>
    <th>Total Noches</th>
</tr>";

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $row['EstablecimientoID'] . "</td>";
    echo "<td>" . $row['NombreHotel'] . "</td>";
    echo "<td>" . $row['Provincia'] . "</td>";
    echo "<td>" . $row['Canton'] . "</td>";
    echo "<td>" . $row['NumReservas'] . "</td>";
    echo "<td>" . $row['TotalNoches'] . "</td>";
    echo "</tr>";
}

echo "</table>";
echo "<br><a href='../public/dashboard.php'>Volver al Dashboard</a>";
?>

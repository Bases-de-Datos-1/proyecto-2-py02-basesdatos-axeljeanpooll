<?php
// conexion.php
$serverName = "DESKTOP-0I3UCHE\\SQLEXPRESS"; // Doble barra para escapar \
$connectionOptions = array(
    "Database" => "SistemaGestionHotelera",
    "Uid" => "proye_hotel",
    "PWD" => "qwerty1234",
    "CharacterSet" => "UTF-8" // Manejar correctamente los caracteres especiales
);

// Intentar conexión
$conn = sqlsrv_connect($serverName, $connectionOptions);

// Verificar si se conectó bien
if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
} else {
    echo "Conexión exitosa a la base de datos.";
}
?>

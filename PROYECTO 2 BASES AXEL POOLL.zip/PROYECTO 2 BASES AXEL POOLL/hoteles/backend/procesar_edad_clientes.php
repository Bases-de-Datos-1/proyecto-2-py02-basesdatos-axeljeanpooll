<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit();
}

include("conexion.php");

// Recoger parametros
$desde = !empty($_POST['desde']) ? $_POST['desde'] : null;
$hasta = !empty($_POST['hasta']) ? $_POST['hasta'] : null;

// Preparar la llamada al SP
$sql = "{CALL sp_ReportEdadClientes(?, ?)}";
$params = array($desde, $hasta);

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Mostrar resultado
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

if ($row) {
    echo "<h2>Resultado del Reporte</h2>";
    echo "<table border='1'>
    <tr>
        <th>Edad Mínima</th>
        <th>Edad Máxima</th>
        <th>Edad Promedio</th>
    </tr>
    <tr>
        <td>" . $row['EdadMinima'] . "</td>
        <td>" . $row['EdadMaxima'] . "</td>
        <td>" . $row['EdadPromedio'] . "</td>
    </tr>
    </table>";
} else {
    echo "No se encontraron datos para ese rango.";
}

echo "<br><a href='../public/dashboard.php'>Volver al Dashboard</a>";
?>

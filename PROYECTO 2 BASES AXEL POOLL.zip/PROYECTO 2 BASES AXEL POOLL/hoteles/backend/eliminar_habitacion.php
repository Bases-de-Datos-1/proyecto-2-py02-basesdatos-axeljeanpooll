<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: ../public/ver_habitaciones.php?mensaje=error_id");
    exit;
}

$habitacionID = (int)$_GET['id'];

// Verificar si la habitación tiene reservas
$sqlCheck = "{CALL sp_VerificarReservasHabitacion(?)}";
$paramsCheck = array($habitacionID);
$stmtCheck = sqlsrv_query($conn, $sqlCheck, $paramsCheck);

if ($stmtCheck === false) {
    header("Location: ../public/ver_habitaciones.php?mensaje=error_bd");
    exit;
}

$row = sqlsrv_fetch_array($stmtCheck, SQLSRV_FETCH_ASSOC);

if ($row && $row['Total'] > 0) {
    header("Location: ../public/ver_habitaciones.php?mensaje=relacionada");
    exit;
}

// Eliminar con procedimiento
$sqlDelete = "{CALL sp_DeleteHabitacion(?)}";
$paramsDelete = array($habitacionID);
$stmtDelete = sqlsrv_query($conn, $sqlDelete, $paramsDelete);

if ($stmtDelete === false) {
    header("Location: ../public/ver_habitaciones.php?mensaje=error_eliminacion");
    exit;
}


if ($stmtDelete !== false) {
    sqlsrv_next_result($stmtDelete); // avanza al siguiente resultado del procedimiento
    $fila = sqlsrv_fetch_array($stmtDelete, SQLSRV_FETCH_ASSOC);
    if ($fila !== false && isset($fila['RowsAffected']) && $fila['RowsAffected'] > 0) {
        header("Location: ../public/ver_habitaciones.php?mensaje=ok");
    } else {
        header("Location: ../public/ver_habitaciones.php?mensaje=error_id");
    }
    exit;
} else {
    header("Location: ../public/ver_habitaciones.php?mensaje=error_eliminacion");
    exit;
}


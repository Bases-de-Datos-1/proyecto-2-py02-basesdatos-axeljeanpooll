<?php
require_once("conexion.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST['actividad_id'];
    $nombreEmpresa = $_POST['nombre_empresa'];
    $cedula = $_POST['cedula_juridica']; // Ya no se usa en este SP
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $nombreContacto = $_POST['nombre_contacto'];
    $provincia = $_POST['provincia'];
    $canton = $_POST['canton'];
    $distrito = $_POST['distrito'];
    $senas = $_POST['senas'];
    $tipoActividad = $_POST['tipo_actividad'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];

    // Llamar al procedimiento almacenado
    $sql = "{CALL sp_UpdateActividad(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
    $params = array(
        $id, $nombreEmpresa, $email, $telefono, $nombreContacto,
        $provincia, $canton, $distrito, $senas,
        $tipoActividad, $descripcion, $precio
    );

    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        echo "Error al actualizar la actividad: ";
        print_r(sqlsrv_errors());
    } else {
        header("Location: ../public/ver_servicios.php");
        exit;
    }
} else {
    echo "Acceso no permitido.";
}

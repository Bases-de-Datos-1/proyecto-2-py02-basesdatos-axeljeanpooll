<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

$id = $_POST['id'] ?? '';
$numero = $_POST['numero'] ?? '';
$establecimiento_id = $_POST['establecimiento_id'] ?? '';
$tipo_id = $_POST['tipo_id'] ?? '';

// Validación básica
if ($id === '' || $numero === '' || $establecimiento_id === '' || $tipo_id === '') {
    die("Todos los campos son obligatorios.");
}

// Llamada al procedimiento almacenado
$sql = "{CALL sp_UpdateHabitacion(?, ?, ?, ?)}";
$params = [
    $id,                // @HabitacionID
    $numero,            // @NumeroHabitacion
    $establecimiento_id, // @EstablecimientoID
    $tipo_id            // @TipoHabitacionID
];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    echo "Error al actualizar habitación: ";
    print_r(sqlsrv_errors(), true);
} else {
    header("Location: ../public/ver_habitaciones.php");
    exit;
}

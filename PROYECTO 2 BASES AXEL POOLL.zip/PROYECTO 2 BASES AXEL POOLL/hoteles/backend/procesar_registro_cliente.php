<?php
session_start();
require_once("conexion.php");

// Obtener datos del formulario
$nombre              = trim($_POST['nombre'] ?? '');
$apellido1           = trim($_POST['apellido1'] ?? '');
$apellido2           = trim($_POST['apellido2'] ?? '');
$fecha_nacimiento    = $_POST['fecha_nacimiento'] ?? '';
$tipo_identificacion = $_POST['tipo_identificacion'] ?? '';
$cedula              = trim($_POST['cedula'] ?? '');
$pais                = trim($_POST['pais'] ?? '');
$provincia           = trim($_POST['provincia'] ?? '');
$canton              = trim($_POST['canton'] ?? '');
$distrito            = trim($_POST['distrito'] ?? '');
$telefono1           = trim($_POST['telefono1'] ?? '');
$telefono2           = trim($_POST['telefono2'] ?? '');
$telefono3           = trim($_POST['telefono3'] ?? '');
$usuario             = trim($_POST['usuario'] ?? '');
$clave               = trim($_POST['clave'] ?? '');
$email               = trim($_POST['email'] ?? '');

// Validar campos obligatorios
if (
    !$nombre || !$apellido1 || !$fecha_nacimiento || !$tipo_identificacion ||
    !$cedula || !$pais || !$telefono1 || !$email || !$usuario || !$clave
) {
    header("Location: ../public/registro_cliente.php?error=Faltan datos obligatorios.");
    exit;
}

// Validar que la cédula no esté repetida
$sql_check = "SELECT 1 FROM Clientes WHERE Cedula = ?";
$params_check = [$cedula];
$stmt_check = sqlsrv_query($conn, $sql_check, $params_check);

if ($stmt_check && sqlsrv_fetch($stmt_check)) {
    header("Location: ../public/registro_cliente.php?error=La cédula ya está registrada.");
    exit;
}

// Llamar al procedimiento almacenado para crear el cliente
$sql = "{CALL sp_CreateCliente(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
$params = [
    $nombre,
    $apellido1,
    $apellido2,
    $fecha_nacimiento,
    $tipo_identificacion,
    $cedula,
    $pais,
    $provincia,
    $canton,
    $distrito,
    $telefono1,
    $telefono2,
    $telefono3,
    $email,
    $usuario,
    $clave
];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt) {
    header("Location: ../public/dashboard_cliente.php");
    exit;
} else {
    echo "<h3>Error al registrar el cliente:</h3>";
    if (($errors = sqlsrv_errors()) != null) {
        foreach ($errors as $error) {
            echo "SQLSTATE: " . $error['SQLSTATE'] . "<br>";
            echo "Código: " . $error['code'] . "<br>";
            echo "Mensaje: " . $error['message'] . "<br><br>";
        }
    } else {
        echo "Error desconocido al insertar cliente.";
    }
    exit;
}

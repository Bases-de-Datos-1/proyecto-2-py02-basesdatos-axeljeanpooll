<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require_once("conexion.php");

// Validar entrada
$reservacionID = isset($_POST['reservacion_id']) ? (int)$_POST['reservacion_id'] : 0;
$metodoPago = trim($_POST['metodo_pago'] ?? '');

if ($reservacionID <= 0 || $metodoPago === '') {
    die("Datos incompletos.");
}

// Obtener detalles de la reservación incluyendo Precio
$sql = "
SELECT 
    r.FechaIngreso, 
    r.FechaSalida,
    th.Precio
FROM Reservaciones r
JOIN Habitaciones h ON r.HabitacionID = h.HabitacionID
JOIN TiposHabitacion th ON h.TipoHabitacionID = th.TipoHabitacionID
WHERE r.ReservacionID = ?
";

$params = [$reservacionID];
$stmt = sqlsrv_query($conn, $sql, $params);

if (!$stmt || !sqlsrv_fetch($stmt)) {
    die("No se encontró la reservación especificada.");
}

$fechaIngreso = sqlsrv_get_field($stmt, 0);
$fechaSalida  = sqlsrv_get_field($stmt, 1);
$precioNoche  = sqlsrv_get_field($stmt, 2);

// Calcular número de noches
$noches = (int) (($fechaSalida->format('U') - $fechaIngreso->format('U')) / 86400); // segundos por día
if ($noches < 1) $noches = 1;

// Calcular total
$importeTotal = $precioNoche * $noches;

// Insertar en Facturación
$sql_insert = "{CALL sp_CreateFacturacion(?, ?, ?, ?)}";
$params_insert = [$reservacionID, $noches, $importeTotal, $metodoPago];

$stmt_insert = sqlsrv_query($conn, $sql_insert, $params_insert);

if ($stmt_insert && sqlsrv_fetch($stmt_insert)) {
    $newID = sqlsrv_get_field($stmt_insert, 0);
    echo "<h2>Factura generada correctamente (ID: $newID)</h2>";
    echo "<p><strong>Noches:</strong> $noches</p>";
    echo "<p><strong>Precio por noche:</strong> ₡" . number_format($precioNoche, 2) . "</p>";
    echo "<p><strong>Total:</strong> ₡" . number_format($importeTotal, 2) . "</p>";
    echo "<p><strong>Método de pago:</strong> $metodoPago</p>";
    echo "<a href='../public/dashboard_admin.php'>← Volver al Dashboard</a>";
} else {
    echo "Error al registrar la factura.";
    if (($errors = sqlsrv_errors()) !== null) {
        foreach ($errors as $e) {
            echo "<br><strong>SQLSTATE:</strong> " . $e['SQLSTATE'];
            echo "<br><strong>Code:</strong> " . $e['code'];
            echo "<br><strong>Message:</strong> " . $e['message'];
        }
    }
}
?>

<?php
session_start();
require_once("conexion.php");

$usuario = $_POST['usuario'] ?? '';
$clave = $_POST['clave'] ?? '';

echo "Conexión exitosa a la base de datos.";

// Consulta a la tabla Clientes
$sql = "SELECT * FROM Clientes WHERE Usuario = ? AND Clave = ?";
$params = array($usuario, $clave);
$stmt = sqlsrv_query($conn, $sql, $params);

// Si encuentra el usuario, crea la sesión y redirige
if ($stmt && sqlsrv_fetch($stmt)) {
    $_SESSION['usuario'] = $usuario;
    $_SESSION['tipo'] = 'cliente';
    header("Location: ../public/dashboard_cliente.php");
    exit;
} else {
    echo "<br>Usuario o clave incorrectos.";
}
?>

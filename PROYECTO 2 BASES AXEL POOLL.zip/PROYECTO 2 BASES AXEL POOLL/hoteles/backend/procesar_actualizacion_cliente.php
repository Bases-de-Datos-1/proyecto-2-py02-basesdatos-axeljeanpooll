<?php
session_start();
require_once("conexion.php");

// Verificar que sea cliente autenticado
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'cliente') {
    header("Location: ../public/login_cliente.html");
    exit;
}

// Obtener usuario actual
$usuario = $_SESSION['usuario'];

// Obtener datos del formulario
$nombre = trim($_POST['nombre'] ?? '');
$apellido1 = trim($_POST['apellido1'] ?? '');
$apellido2 = trim($_POST['apellido2'] ?? '');
$fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
$tipo_identificacion = $_POST['tipo_identificacion'] ?? '';
$pais = trim($_POST['pais'] ?? '');
$provincia = trim($_POST['provincia'] ?? '');
$canton = trim($_POST['canton'] ?? '');
$distrito = trim($_POST['distrito'] ?? '');
$telefono1 = trim($_POST['telefono1'] ?? '');
$telefono2 = trim($_POST['telefono2'] ?? '');
$telefono3 = trim($_POST['telefono3'] ?? '');
$email = trim($_POST['email'] ?? '');
$clave = trim($_POST['clave'] ?? '');

// Validar campos mínimos
if (!$nombre || !$apellido1 || !$fecha_nacimiento || !$tipo_identificacion || !$pais || !$telefono1 || !$email || !$clave) {
    header("Location: ../public/perfil_cliente.php?error=Faltan campos obligatorios");
    exit;
}

// Preparar sentencia UPDATE
$sql = "UPDATE Clientes SET 
            Nombre = ?, 
            PrimerApellido = ?, 
            SegundoApellido = ?, 
            FechaNacimiento = ?, 
            TipoIdentificacion = ?, 
            PaisResidencia = ?, 
            Provincia = ?, 
            Canton = ?, 
            Distrito = ?, 
            Telefono1 = ?, 
            Telefono2 = ?, 
            Telefono3 = ?, 
            Email = ?, 
            Clave = ?
        WHERE Usuario = ?";

$params = [
    $nombre,
    $apellido1,
    $apellido2,
    $fecha_nacimiento,
    $tipo_identificacion,
    $pais,
    $provincia,
    $canton,
    $distrito,
    $telefono1,
    $telefono2,
    $telefono3,
    $email,
    $clave,
    $usuario
];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt) {
    header("Location: ../public/perfil_cliente.php?mensaje=Datos actualizados correctamente");
} else {
    header("Location: ../public/perfil_cliente.php?error=Error al actualizar los datos");
}
exit;

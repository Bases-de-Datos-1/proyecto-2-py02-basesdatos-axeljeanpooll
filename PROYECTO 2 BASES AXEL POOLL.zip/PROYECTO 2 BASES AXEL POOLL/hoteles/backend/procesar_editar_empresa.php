<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit();
}

require_once("conexion.php");

$id                 = (int)($_POST['id'] ?? 0);
$establecimiento_id = trim($_POST['establecimiento_id'] ?? '');
$nombre             = trim($_POST['nombre'] ?? '');
$cedula             = trim($_POST['cedula'] ?? '');
$email              = trim($_POST['email'] ?? '');
$telefono           = trim($_POST['telefono'] ?? '');
$contacto           = trim($_POST['contacto'] ?? '');
$provincia          = trim($_POST['provincia'] ?? '');
$canton             = trim($_POST['canton'] ?? '');
$distrito           = trim($_POST['distrito'] ?? '');
$senas              = trim($_POST['senas'] ?? '');
$tipo               = trim($_POST['tipo'] ?? '');
$descripcion        = trim($_POST['descripcion'] ?? '');
$precio             = isset($_POST['precio']) ? floatval($_POST['precio']) : 0;

if ($id <= 0 || !$establecimiento_id || !$nombre || !$cedula || !$email || !$telefono || !$contacto || !$provincia || !$canton || !$distrito || !$senas || !$tipo || $precio <= 0) {
    echo "Faltan datos requeridos.";
    exit();
}

// Llamar al procedimiento almacenado
$sql = "{CALL sp_UpdateActividad2(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

$params = [
    $id,
    $establecimiento_id,
    $nombre,
    $cedula,
    $email,
    $telefono,
    $contacto,
    $provincia,
    $canton,
    $distrito,
    $senas,
    $tipo,
    $descripcion,
    $precio
];

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    echo "Error al actualizar: ";
    print_r(sqlsrv_errors());
    exit();
}

header("Location: ../public/ver_empresas.php?mensaje=Empresa actualizada correctamente");
exit();

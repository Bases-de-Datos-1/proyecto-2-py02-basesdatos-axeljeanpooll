<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit();
}

include("conexion.php");

// Recoger valores del formulario
$desde = !empty($_POST['desde']) ? $_POST['desde'] : null;
$hasta = !empty($_POST['hasta']) ? $_POST['hasta'] : null;
$agrupamiento = $_POST['agrupamiento'] ?? 'DIA';
$tipo = isset($_POST['tipo_habitacion']) && $_POST['tipo_habitacion'] !== '' ? $_POST['tipo_habitacion'] : null;
$habitacion = isset($_POST['habitacion_id']) && $_POST['habitacion_id'] !== '' ? (int)$_POST['habitacion_id'] : null;

// Armar la llamada al procedimiento
$sql = "{CALL sp_ReportFacturacion(?, ?, ?, ?, ?)}";
$params = array($desde, $hasta, $agrupamiento, $tipo, $habitacion);

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Mostrar resultados en tabla
echo "<h2>Resultado del Reporte</h2>";
echo "<table border='1'>
<tr>
    <th>Periodo</th>
    <th>N° Facturas</th>
    <th>Total Facturado</th>
</tr>";

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $row['Periodo'] . "</td>";
    echo "<td>" . $row['NumFacturas'] . "</td>";
    echo "<td>₡" . number_format($row['TotalFacturado'], 2) . "</td>";
    echo "</tr>";
}

echo "</table>";
echo "<br><a href='../public/dashboard.php'>Volver al Dashboard</a>";
?>

<?php
require_once("conexion.php");

echo "Conexion exitosa a la base de datos.";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $establecimientoID = $_POST['establecimiento_id'];
    $nombreEmpresa = $_POST['nombre_empresa'];
    $cedula = $_POST['cedula_juridica'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $nombreContacto = $_POST['nombre_contacto'];
    $provincia = $_POST['provincia'];
    $canton = $_POST['canton'];
    $distrito = $_POST['distrito'];
    $senas = $_POST['senas'];
    $tipoActividad = $_POST['tipo_actividad'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];

    $sql = "{CALL sp_CreateActividad(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
    $params = array(
        $establecimientoID, $nombreEmpresa, $cedula, $email,
        $telefono, $nombreContacto, $provincia, $canton,
        $distrito, $senas, $tipoActividad, $descripcion, $precio
    );

    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        echo "Error al insertar la actividad: ";
        print_r(sqlsrv_errors());
    } else {
        header("Location: ../public/ver_servicios.php");
        exit;
    }
} else {
    echo "Acceso no permitido.";
}

<?php
require_once("conexion.php");

if (!isset($_GET['id'])) {
    die("ID no especificado.");
}

$id = $_GET['id'];

// Llamada al procedimiento almacenado para eliminar
$sql = "{CALL sp_DeleteActividad(?)}";
$params = array($id);
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die("Error al eliminar la actividad: " . print_r(sqlsrv_errors(), true));
} else {
    header("Location: ../public/ver_servicios.php");
    exit;
}

<?php
// archivo: backend/eliminar_reserva.php

session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../public/login.html");
    exit;
}

require_once("conexion.php");

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $sql = "DELETE FROM Reservaciones WHERE ReservacionID = ?";
    $stmt = sqlsrv_prepare($conn, $sql, array(&$id));

    if ($stmt && sqlsrv_execute($stmt)) {
        header("Location: ../public/ver_reservas_admin.php?msg=eliminada");
    } else {
        die("Error al eliminar: " . print_r(sqlsrv_errors(), true));
    }
} else {
    echo "ID de reserva no proporcionado.";
}

<?php
require_once("conexion.php");

if (!isset($_GET['id'])) {
    die("ID no proporcionado.");
}

$id = intval($_GET['id']);

$sql = "{CALL sp_DeleteEstablecimiento_Cascada(?)}";
$stmt = sqlsrv_query($conn, $sql, [$id]);

if ($stmt) {
    // No intentamos acceder al resultado porque no necesitamos validarlo
    header("Location: ../public/ver_establecimientos.php");
    exit;
} else {
    echo "Error al eliminar: ";
    print_r(sqlsrv_errors());
}

-- Crear un nuevo inicio de sesi�n (login)
CREATE LOGIN proye_hotel WITH PASSWORD = 'qwerty1234';

-- Crear usuario dentro de tu base de datos
USE SistemaGestionHotelera;
CREATE USER proye_hotel FOR LOGIN proye_hotel;

-- Darle permisos b�sicos (lectura y escritura)
ALTER ROLE db_datareader ADD MEMBER proye_hotel;
ALTER ROLE db_datawriter ADD MEMBER proye_hotel;

SELECT name FROM sys.server_principals WHERE type_desc = 'SQL_LOGIN';


SELECT name FROM sys.database_principals WHERE type_desc = 'SQL_USER';

----------------------------------------------------------------------------------

USE SistemaGestionHotelera;

CREATE TABLE Administradores (
    id INT PRIMARY KEY IDENTITY(1,1),
    usuario VARCHAR(50) NOT NULL UNIQUE,
    clave VARCHAR(255) NOT NULL
);

-- Insertar un admin de prueba
INSERT INTO Administradores (usuario, clave)
VALUES ('pooll12', 'qwerty');


SELECT * FROM Administradores;

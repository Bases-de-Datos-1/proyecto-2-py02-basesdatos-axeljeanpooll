-- Verifica y crea la base de datos si no existe
IF DB_ID('SistemaGestionHotelera') IS NULL
BEGIN
    CREATE DATABASE SistemaGestionHotelera;
END;
GO

USE SistemaGestionHotelera;
GO


-- Permisos

-- Hoteles/Establecimientos
GRANT EXECUTE ON sp_buscar_hoteles TO proye_hotel;
GRANT EXECUTE ON sp_actualizar_establecimiento TO proye_hotel;
GRANT EXECUTE ON sp_DeleteEstablecimiento_Cascada TO proye_hotel;
GRANT EXECUTE ON sp_listar_establecimientos TO proye_hotel;
GRANT EXECUTE ON sp_insertar_establecimiento TO proye_hotel;
GRANT EXECUTE ON sp_obtener_establecimiento_por_id TO proye_hotel;

-- Tipos de Habitacion
GRANT EXECUTE ON sp_GetTiposHabitacion TO proye_hotel;
GRANT EXECUTE ON sp_CreateTipoHabitacion TO proye_hotel;
GRANT EXECUTE ON sp_UpdateTipoHabitacion TO proye_hotel;
GRANT EXECUTE ON sp_DeleteTipoHabitacion TO proye_hotel;
GRANT EXECUTE ON sp_GetTipoHabitacionByID TO proye_hotel;

-- Habitacion
GRANT EXECUTE ON sp_CreateHabitacion TO proye_hotel;
GRANT EXECUTE ON sp_GetHabitaciones TO proye_hotel;
GRANT EXECUTE ON sp_UpdateHabitacion TO proye_hotel;
GRANT EXECUTE ON sp_DeleteHabitacion TO proye_hotel;
GRANT EXECUTE ON sp_VerificarReservasHabitacion TO proye_hotel;

-- Cliente
GRANT EXECUTE ON sp_CreateCliente TO proye_hotel;
GRANT EXECUTE ON sp_GetClientes TO proye_hotel;
GRANT EXECUTE ON sp_UpdateCliente TO proye_hotel;
GRANT EXECUTE ON sp_DeleteCliente TO proye_hotel;

--Empresa
GRANT SELECT ON vw_EmpresasAliadas TO proye_hotel;
GRANT EXECUTE ON sp_CreateActividad TO proye_hotel;
GRANT EXECUTE ON sp_UpdateActividad TO proye_hotel;
GRANT EXECUTE ON sp_UpdateActividad2 TO proye_hotel;
GRANT EXECUTE ON sp_DeleteActividad TO proye_hotel;




-- Actividades
GRANT EXECUTE ON sp_GetActividades TO proye_hotel;
GRANT EXECUTE ON OBJECT::dbo.sp_BuscarActividades TO proye_hotel;
GRANT EXECUTE ON sp_CreateActividad TO proye_hotel;
GRANT EXECUTE ON sp_UpdateActividad TO proye_hotel;
GRANT EXECUTE ON sp_DeleteActividad TO proye_hotel;



--Reservas

--Facturacion
GRANT EXECUTE ON sp_ReportFacturacion TO proye_hotel;
GRANT EXECUTE ON sp_ReportUsoPorTipo TO proye_hotel;
GRANT EXECUTE ON sp_ReportEdadClientes TO proye_hotel;
GRANT EXECUTE ON sp_ReportHotelesDemanda TO proye_hotel;

-- Reportes

--Facturacion

--Uso por tipo

-- Edades de clientes

-- Hoteles por demanda

GO





--------------------------------------------------------------------------------
-- Tabla: Establecimientos (Datos de los establecimientos de hospedaje)
--------------------------------------------------------------------------------
CREATE TABLE Establecimientos (
    EstablecimientoID INT IDENTITY(1,1) PRIMARY KEY,
    NombreHotel NVARCHAR(100) NOT NULL,
    CedulaJuridica NVARCHAR(20) NOT NULL UNIQUE,
    Tipo NVARCHAR(50) NOT NULL,  -- Ej: Hotel, Hostal, Casa, etc.
    Provincia NVARCHAR(50) NOT NULL,
    Canton NVARCHAR(50) NOT NULL,
    Distrito NVARCHAR(50) NOT NULL,
    Barrio NVARCHAR(50) NOT NULL,
    Senas NVARCHAR(200) NOT NULL,
    Referencia NVARCHAR(100) NULL,
    Telefonos NVARCHAR(100) NULL, -- Lista de tel�fonos; se puede normalizar en otra tabla
    Email NVARCHAR(100) NULL,
    URLSitioWeb NVARCHAR(100) NULL,
    Facebook NVARCHAR(100) NULL,
    Instagram NVARCHAR(100) NULL,
    YouTube NVARCHAR(100) NULL,
    TikTok NVARCHAR(100) NULL,
    Airbnb NVARCHAR(100) NULL,
    Threads NVARCHAR(100) NULL,
    X_Red NVARCHAR(100) NULL,
    ListaServicios NVARCHAR(200) NULL  -- Ej: piscina, WiFi, restaurante, etc.
);
GO

--------------------------------------------------------------------------------
-- Tabla: TiposHabitacion (Definici�n de tipos de habitaciones)
--------------------------------------------------------------------------------
CREATE TABLE TiposHabitacion (
    TipoHabitacionID INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(50) NOT NULL,
    Descripcion NVARCHAR(200) NULL,
    Comodidades NVARCHAR(200) NULL,  -- Ej: WiFi en habitaci�n, A/C, ventilador, etc.
    Precio DECIMAL(10,2) NOT NULL,
    Fotos NVARCHAR(200) NULL        -- Ruta o URL de imagen(es)
);
GO

--------------------------------------------------------------------------------
-- Tabla: Habitaciones (Asignaci�n de habitaciones a cada establecimiento)
--------------------------------------------------------------------------------
CREATE TABLE Habitaciones (
    HabitacionID INT IDENTITY(1,1) PRIMARY KEY,
    EstablecimientoID INT NOT NULL,
    NumeroHabitacion NVARCHAR(20) NOT NULL, -- N�mero o c�digo de la habitaci�n
    TipoHabitacionID INT NOT NULL,
    CONSTRAINT FK_Habitaciones_Establecimientos FOREIGN KEY (EstablecimientoID)
       REFERENCES Establecimientos(EstablecimientoID),
    CONSTRAINT FK_Habitaciones_TiposHabitacion FOREIGN KEY (TipoHabitacionID)
       REFERENCES TiposHabitacion(TipoHabitacionID)
);
GO

--------------------------------------------------------------------------------
-- Tabla: Clientes (Informaci�n de los clientes)
--------------------------------------------------------------------------------
CREATE TABLE Clientes (
    ClienteID INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(50) NOT NULL,
    PrimerApellido NVARCHAR(50) NOT NULL,
    SegundoApellido NVARCHAR(50) NULL,
    FechaNacimiento DATE NOT NULL,
    TipoIdentificacion NVARCHAR(50) NOT NULL,
    Cedula NVARCHAR(20) NOT NULL UNIQUE,
    PaisResidencia NVARCHAR(50) NOT NULL,
    -- Si el cliente es costarricense, se registran estos datos:
    Provincia NVARCHAR(50) NULL,
    Canton NVARCHAR(50) NULL,
    Distrito NVARCHAR(50) NULL,
    Telefono1 NVARCHAR(20) NULL,
    Telefono2 NVARCHAR(20) NULL,
    Telefono3 NVARCHAR(20) NULL,
    Email NVARCHAR(100) NOT NULL,
	-- Hay que agregar usuario y clave para la parte web
	Usuario NVARCHAR(50) NOT NULL UNIQUE,
	Clave NVARCHAR(100) NOT NULL
);
GO

--------------------------------------------------------------------------------
-- Tabla: Administradores (Informaci�n de los administradores)
--------------------------------------------------------------------------------
CREATE TABLE Administradores (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Usuario VARCHAR(50) UNIQUE NOT NULL,
    Clave VARCHAR(255) NOT NULL
);

--------------------------------------------------------------------------------
-- Tabla: Reservaciones (Registro de reservaciones de habitaciones)
--------------------------------------------------------------------------------
CREATE TABLE Reservaciones (
    ReservacionID INT IDENTITY(1,1) PRIMARY KEY,
    NumeroReserva NVARCHAR(50) NOT NULL UNIQUE,  -- N�mero de reserva �nico para b�squedas
    ClienteID INT NOT NULL,
    HabitacionID INT NOT NULL,
    FechaIngreso DATETIME NOT NULL,
    CantidadPersonas INT NOT NULL,
    PoseeVehiculo BIT NOT NULL,  -- 0 = No, 1 = S�
    FechaSalida DATETIME NOT NULL,
    CONSTRAINT FK_Reservaciones_Clientes FOREIGN KEY (ClienteID)
       REFERENCES Clientes(ClienteID),
    CONSTRAINT FK_Reservaciones_Habitaciones FOREIGN KEY (HabitacionID)
       REFERENCES Habitaciones(HabitacionID)
);
GO

--------------------------------------------------------------------------------
-- Tabla: Facturacion (Datos de la facturaci�n asociados a una reservaci�n)
--------------------------------------------------------------------------------
CREATE TABLE Facturacion (
    FacturacionID INT IDENTITY(1,1) PRIMARY KEY,
    ReservacionID INT NOT NULL,
    NochesEstadia INT NOT NULL, -- Se puede calcular en funci�n de FechaIngreso y FechaSalida
    ImporteTotal DECIMAL(10,2) NOT NULL,
    MetodoPago NVARCHAR(50) NOT NULL, -- Ej: 'efectivo' o 'tarjeta de cr�dito'
    CONSTRAINT FK_Facturacion_Reservaciones FOREIGN KEY (ReservacionID)
       REFERENCES Reservaciones(ReservacionID)
);
GO

-- Restricci�n para garantizar que el m�todo de pago solo sea 'efectivo' o 'tarjeta de cr�dito'
ALTER TABLE Facturacion
ADD CONSTRAINT CHK_MetodoPago CHECK (MetodoPago IN ('efectivo', 'tarjeta de cr�dito'));
GO

--------------------------------------------------------------------------------
-- Tabla: ActividadesRecreacion (Servicios de actividades de recreaci�n)
-- Ahora vinculada directamente a Establecimientos
--------------------------------------------------------------------------------
CREATE TABLE ActividadesRecreacion (
    ActividadID INT IDENTITY(1,1) PRIMARY KEY,
    EstablecimientoID INT NOT NULL,
    NombreEmpresa NVARCHAR(100) NOT NULL,
    CedulaJuridica NVARCHAR(20) NOT NULL,
    Email NVARCHAR(100) NOT NULL,
    Telefono NVARCHAR(20) NOT NULL,
    NombreContacto NVARCHAR(100) NOT NULL,
    Provincia NVARCHAR(50) NOT NULL,
    Canton NVARCHAR(50) NOT NULL,
    Distrito NVARCHAR(50) NOT NULL,
    Senas NVARCHAR(200) NOT NULL,
    TipoActividad NVARCHAR(200) NOT NULL,  -- Puede incluir varias actividades
    Descripcion NVARCHAR(200) NULL,
    Precio DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_ActRec_Estab FOREIGN KEY (EstablecimientoID)
       REFERENCES Establecimientos(EstablecimientoID)
);
GO

--------------------------------------------------------------------------------
-- �ndices adicionales para optimizar b�squedas
--------------------------------------------------------------------------------
CREATE INDEX IDX_Establecimientos_Nombre ON Establecimientos(NombreHotel);
CREATE INDEX IDX_Establecimientos_Provincia ON Establecimientos(Provincia);
CREATE INDEX IDX_Establecimientos_Tipo ON Establecimientos(Tipo);

CREATE INDEX IDX_Clientes_Cedula ON Clientes(Cedula);

CREATE INDEX IDX_Reservaciones_NumeroReserva ON Reservaciones(NumeroReserva);

CREATE INDEX IDX_ActRec_Estab ON ActividadesRecreacion(EstablecimientoID);
GO

-- ==========================================================
-- Script de CRUD completo para todas las entidades
-- Incluye procedimientos almacenados y pruebas de funcionalidad
-- Base de datos: SistemaGestionHotelera
-- ==========================================================

USE SistemaGestionHotelera;
GO
SELECT name FROM sys.procedures ORDER BY name;

--------------------------------------------------------------------------------
-- 1. CRUD: Establecimientos
--------------------------------------------------------------------------------
-- CREATE
IF OBJECT_ID('sp_CreateEstablecimiento','P') IS NOT NULL DROP PROCEDURE sp_CreateEstablecimiento;
GO
CREATE PROCEDURE sp_CreateEstablecimiento
  @NombreHotel     NVARCHAR(100),
  @CedulaJuridica  NVARCHAR(20),
  @Tipo            NVARCHAR(50),
  @Provincia       NVARCHAR(50),
  @Canton          NVARCHAR(50),
  @Distrito        NVARCHAR(50),
  @Barrio          NVARCHAR(50),
  @Senas           NVARCHAR(200),
  @Referencia      NVARCHAR(100)=NULL,
  @Telefonos       NVARCHAR(100)=NULL,
  @Email           NVARCHAR(100)=NULL,
  @URLSitioWeb     NVARCHAR(100)=NULL,
  @Facebook        NVARCHAR(100)=NULL,
  @Instagram       NVARCHAR(100)=NULL,
  @YouTube         NVARCHAR(100)=NULL,
  @TikTok          NVARCHAR(100)=NULL,
  @Airbnb          NVARCHAR(100)=NULL,
  @Threads         NVARCHAR(100)=NULL,
  @X_Red           NVARCHAR(100)=NULL,
  @ListaServicios  NVARCHAR(200)=NULL
AS
BEGIN
  INSERT INTO Establecimientos(
    NombreHotel, CedulaJuridica, Tipo,
    Provincia, Canton, Distrito, Barrio, Senas,
    Referencia, Telefonos, Email, URLSitioWeb,
    Facebook, Instagram, YouTube, TikTok,
    Airbnb, Threads, X_Red, ListaServicios
  ) VALUES (
    @NombreHotel, @CedulaJuridica, @Tipo,
    @Provincia, @Canton, @Distrito, @Barrio, @Senas,
    @Referencia, @Telefonos, @Email, @URLSitioWeb,
    @Facebook, @Instagram, @YouTube, @TikTok,
    @Airbnb, @Threads, @X_Red, @ListaServicios
  );
  SELECT SCOPE_IDENTITY() AS NewID;
END;
GO

-- READ
IF OBJECT_ID('sp_GetEstablecimientos','P') IS NOT NULL DROP PROCEDURE sp_GetEstablecimientos;
GO
CREATE PROCEDURE sp_GetEstablecimientos
  @Nombre    NVARCHAR(100)=NULL,
  @Provincia NVARCHAR(50)=NULL,
  @Tipo      NVARCHAR(50)=NULL
AS
BEGIN
  SELECT * FROM Establecimientos
  WHERE (@Nombre    IS NULL OR NombreHotel LIKE '%'+@Nombre+'%')
    AND (@Provincia IS NULL OR Provincia = @Provincia)
    AND (@Tipo      IS NULL OR Tipo = @Tipo);
END;
GO

-- UPDATE
IF OBJECT_ID('sp_UpdateEstablecimiento','P') IS NOT NULL DROP PROCEDURE sp_UpdateEstablecimiento;
GO
CREATE PROCEDURE sp_UpdateEstablecimiento
  @EstablecimientoID INT,
  @NombreHotel       NVARCHAR(100)=NULL,
  @Tipo              NVARCHAR(50)=NULL,
  @Provincia         NVARCHAR(50)=NULL,
  @Canton            NVARCHAR(50)=NULL,
  @Distrito          NVARCHAR(50)=NULL,
  @ListaServicios    NVARCHAR(200)=NULL,
  @Facebook          NVARCHAR(100)=NULL,
  @Instagram         NVARCHAR(100)=NULL,
  @YouTube           NVARCHAR(100)=NULL,
  @TikTok            NVARCHAR(100)=NULL,
  @Airbnb            NVARCHAR(100)=NULL,
  @Threads           NVARCHAR(100)=NULL,
  @X_Red             NVARCHAR(100)=NULL
AS
BEGIN
  UPDATE Establecimientos
  SET NombreHotel    = COALESCE(@NombreHotel, NombreHotel),
      Tipo           = COALESCE(@Tipo, Tipo),
      Provincia      = COALESCE(@Provincia, Provincia),
      Canton         = COALESCE(@Canton, Canton),
      Distrito       = COALESCE(@Distrito, Distrito),
      ListaServicios = COALESCE(@ListaServicios, ListaServicios),
      Facebook       = COALESCE(@Facebook, Facebook),
      Instagram      = COALESCE(@Instagram, Instagram),
      YouTube        = COALESCE(@YouTube, YouTube),
      TikTok         = COALESCE(@TikTok, TikTok),
      Airbnb         = COALESCE(@Airbnb, Airbnb),
      Threads        = COALESCE(@Threads, Threads),
      X_Red          = COALESCE(@X_Red, X_Red)
  WHERE EstablecimientoID=@EstablecimientoID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- DELETE
IF OBJECT_ID('sp_DeleteEstablecimiento_Cascada','P') IS NOT NULL
    DROP PROCEDURE sp_DeleteEstablecimiento_Cascada;
GO
CREATE PROCEDURE sp_DeleteEstablecimiento_Cascada
    @EstablecimientoID INT
AS
BEGIN
    -- Eliminar habitaciones asociadas
    DELETE FROM Habitaciones WHERE EstablecimientoID = @EstablecimientoID;

    -- Eliminar el establecimiento
    DELETE FROM Establecimientos WHERE EstablecimientoID = @EstablecimientoID;

    SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

--------------------------------------------------------------------------------
-- 2. CRUD: TiposHabitacion
--------------------------------------------------------------------------------
-- CREATE
IF OBJECT_ID('sp_CreateTipoHabitacion','P') IS NOT NULL DROP PROCEDURE sp_CreateTipoHabitacion;
GO
CREATE PROCEDURE sp_CreateTipoHabitacion
  @Nombre       NVARCHAR(50),
  @Descripcion  NVARCHAR(200)=NULL,
  @Comodidades  NVARCHAR(200)=NULL,
  @Precio       DECIMAL(10,2),
  @Fotos        NVARCHAR(200)=NULL
AS
BEGIN
  INSERT INTO TiposHabitacion(Nombre,Descripcion,Comodidades,Precio,Fotos)
  VALUES(@Nombre,@Descripcion,@Comodidades,@Precio,@Fotos);
  SELECT SCOPE_IDENTITY() AS NewID;
END;
GO

-- READ
IF OBJECT_ID('sp_GetTiposHabitacion','P') IS NOT NULL DROP PROCEDURE sp_GetTiposHabitacion;
GO
CREATE PROCEDURE sp_GetTiposHabitacion
  @Nombre    NVARCHAR(50)=NULL,
  @PrecioMin DECIMAL(10,2)=NULL,
  @PrecioMax DECIMAL(10,2)=NULL
AS
BEGIN
  SELECT * FROM TiposHabitacion
  WHERE (@Nombre IS NULL OR Nombre LIKE '%'+@Nombre+'%')
    AND (@PrecioMin IS NULL OR Precio>=@PrecioMin)
    AND (@PrecioMax IS NULL OR Precio<=@PrecioMax);
END;
GO

-- UPDATE
IF OBJECT_ID('sp_UpdateTipoHabitacion','P') IS NOT NULL DROP PROCEDURE sp_UpdateTipoHabitacion;
GO
CREATE PROCEDURE sp_UpdateTipoHabitacion
  @TipoHabitacionID INT,
  @Nombre           NVARCHAR(50)=NULL,
  @Descripcion      NVARCHAR(200)=NULL,
  @Comodidades      NVARCHAR(200)=NULL,
  @Precio           DECIMAL(10,2)=NULL,
  @Fotos            NVARCHAR(200)=NULL
AS
BEGIN
  UPDATE TiposHabitacion
  SET Nombre      = COALESCE(@Nombre, Nombre),
      Descripcion = COALESCE(@Descripcion, Descripcion),
      Comodidades = COALESCE(@Comodidades, Comodidades),
      Precio      = COALESCE(@Precio, Precio),
      Fotos       = COALESCE(@Fotos, Fotos)
  WHERE TipoHabitacionID=@TipoHabitacionID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- DELETE
IF OBJECT_ID('sp_DeleteTipoHabitacion','P') IS NOT NULL DROP PROCEDURE sp_DeleteTipoHabitacion;
GO
CREATE PROCEDURE sp_DeleteTipoHabitacion
  @TipoHabitacionID INT
AS
BEGIN
  DELETE FROM TiposHabitacion WHERE TipoHabitacionID=@TipoHabitacionID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

--------------------------------------------------------------------------------
-- 3. CRUD: Habitaciones
--------------------------------------------------------------------------------
-- CREATE
IF OBJECT_ID('sp_CreateHabitacion','P') IS NOT NULL DROP PROCEDURE sp_CreateHabitacion;
GO
CREATE PROCEDURE sp_CreateHabitacion
  @NumeroHabitacion  NVARCHAR(20),
  @EstablecimientoID INT,
  @TipoHabitacionID  INT
AS
BEGIN
  INSERT INTO Habitaciones(NumeroHabitacion,EstablecimientoID,TipoHabitacionID)
  VALUES(@NumeroHabitacion,@EstablecimientoID,@TipoHabitacionID);
  SELECT SCOPE_IDENTITY() AS NewID;
END;
GO

-- READ
IF OBJECT_ID('sp_GetHabitaciones','P') IS NOT NULL DROP PROCEDURE sp_GetHabitaciones;
GO

CREATE PROCEDURE sp_GetHabitaciones
  @EstablecimientoID INT=NULL,
  @TipoHabitacionID  INT=NULL
AS
BEGIN
  SELECT h.HabitacionID,h.NumeroHabitacion,e.NombreHotel,th.Nombre AS Tipo
  FROM Habitaciones h
  JOIN Establecimientos e ON h.EstablecimientoID=e.EstablecimientoID
  JOIN TiposHabitacion th ON h.TipoHabitacionID=th.TipoHabitacionID
  WHERE (@EstablecimientoID IS NULL OR h.EstablecimientoID=@EstablecimientoID)
    AND (@TipoHabitacionID  IS NULL OR h.TipoHabitacionID=@TipoHabitacionID);
END;
GO

-- UPDATE
IF OBJECT_ID('sp_UpdateHabitacion','P') IS NOT NULL DROP PROCEDURE sp_UpdateHabitacion;
GO
CREATE PROCEDURE sp_UpdateHabitacion
  @HabitacionID      INT,
  @NumeroHabitacion  NVARCHAR(20)=NULL,
  @EstablecimientoID INT=NULL,
  @TipoHabitacionID  INT=NULL
AS
BEGIN
  UPDATE Habitaciones
  SET NumeroHabitacion  = COALESCE(@NumeroHabitacion, NumeroHabitacion),
      EstablecimientoID = COALESCE(@EstablecimientoID,EstablecimientoID),
      TipoHabitacionID  = COALESCE(@TipoHabitacionID,TipoHabitacionID)
  WHERE HabitacionID=@HabitacionID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- DELETE
IF OBJECT_ID('sp_DeleteHabitacion','P') IS NOT NULL DROP PROCEDURE sp_DeleteHabitacion;
GO
CREATE PROCEDURE sp_DeleteHabitacion
  @HabitacionID INT
AS
BEGIN
  DELETE FROM Habitaciones WHERE HabitacionID=@HabitacionID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- Verificar reservas
IF OBJECT_ID('sp_VerificarReservasHabitacion','P') IS NOT NULL DROP PROCEDURE sp_VerificarReservasHabitacion;
GO
CREATE PROCEDURE sp_VerificarReservasHabitacion
  @HabitacionID INT
AS
BEGIN
  SELECT COUNT(*) AS Total FROM Reservaciones WHERE HabitacionID = @HabitacionID;
END;
GO

--------------------------------------------------------------------------------
-- 4. CRUD: Clientes
--------------------------------------------------------------------------------
-- CREATE
IF OBJECT_ID('sp_CreateCliente','P') IS NOT NULL DROP PROCEDURE sp_CreateCliente;
GO
CREATE PROCEDURE sp_CreateCliente
  @Nombre             NVARCHAR(50),
  @PrimerApellido     NVARCHAR(50),
  @SegundoApellido    NVARCHAR(50) = NULL,
  @FechaNacimiento    DATE,
  @TipoIdentificacion NVARCHAR(50),
  @Cedula             NVARCHAR(20),
  @PaisResidencia     NVARCHAR(50),
  @Provincia          NVARCHAR(50) = NULL,
  @Canton             NVARCHAR(50) = NULL,
  @Distrito           NVARCHAR(50) = NULL,
  @Telefono1          NVARCHAR(20) = NULL,
  @Telefono2          NVARCHAR(20) = NULL,
  @Telefono3          NVARCHAR(20) = NULL,
  @Email              NVARCHAR(100),
  @Usuario            NVARCHAR(50),
  @Clave              NVARCHAR(100)
AS
BEGIN
  INSERT INTO Clientes(
    Nombre, PrimerApellido, SegundoApellido, FechaNacimiento,
    TipoIdentificacion, Cedula, PaisResidencia, Provincia, Canton, Distrito,
    Telefono1, Telefono2, Telefono3, Email, Usuario, Clave
  ) VALUES (
    @Nombre, @PrimerApellido, @SegundoApellido, @FechaNacimiento,
    @TipoIdentificacion, @Cedula, @PaisResidencia, @Provincia, @Canton, @Distrito,
    @Telefono1, @Telefono2, @Telefono3, @Email, @Usuario, @Clave
  );

  SELECT SCOPE_IDENTITY() AS NewID;
END;
GO
select * from clientes;

-- READ
IF OBJECT_ID('sp_GetClientes','P') IS NOT NULL DROP PROCEDURE sp_GetClientes;
GO
CREATE PROCEDURE sp_GetClientes
  @Cedula         NVARCHAR(20)=NULL,
  @Nombre         NVARCHAR(50)=NULL,
  @PaisResidencia NVARCHAR(50)=NULL
AS
BEGIN
  SELECT * FROM Clientes
  WHERE (@Cedula         IS NULL OR Cedula         = @Cedula)
    AND (@Nombre         IS NULL OR Nombre        LIKE '%'+@Nombre+'%')
    AND (@PaisResidencia IS NULL OR PaisResidencia = @PaisResidencia);
END;
GO

-- UPDATE
IF OBJECT_ID('sp_UpdateCliente','P') IS NOT NULL DROP PROCEDURE sp_UpdateCliente;
GO
CREATE PROCEDURE sp_UpdateCliente
  @ClienteID         INT,
  @Nombre            NVARCHAR(50)=NULL,
  @PrimerApellido    NVARCHAR(50)=NULL,
  @SegundoApellido   NVARCHAR(50)=NULL,
  @Provincia         NVARCHAR(50)=NULL,
  @Canton            NVARCHAR(50)=NULL,
  @Distrito          NVARCHAR(50)=NULL,
  @Telefono1         NVARCHAR(20)=NULL,
  @Telefono2         NVARCHAR(20)=NULL,
  @Telefono3         NVARCHAR(20)=NULL,
  @Email             NVARCHAR(100)=NULL
AS
BEGIN
  UPDATE Clientes
  SET Nombre          = COALESCE(@Nombre, Nombre),
      PrimerApellido  = COALESCE(@PrimerApellido, PrimerApellido),
      SegundoApellido = COALESCE(@SegundoApellido,SegundoApellido),
      Provincia       = COALESCE(@Provincia, Provincia),
      Canton          = COALESCE(@Canton, Canton),
      Distrito        = COALESCE(@Distrito,Distrito),
      Telefono1       = COALESCE(@Telefono1, Telefono1),
      Telefono2       = COALESCE(@Telefono2, Telefono2),
      Telefono3       = COALESCE(@Telefono3, Telefono3),
      Email           = COALESCE(@Email, Email)
  WHERE ClienteID=@ClienteID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- DELETE
IF OBJECT_ID('sp_DeleteCliente','P') IS NOT NULL DROP PROCEDURE sp_DeleteCliente;
GO
CREATE PROCEDURE sp_DeleteCliente
  @ClienteID INT
AS
BEGIN
  DELETE FROM Clientes WHERE ClienteID=@ClienteID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

--------------------------------------------------------------------------------
-- 5. CRUD: Reservaciones
--------------------------------------------------------------------------------
-- CREATE
IF OBJECT_ID('sp_CreateReservacion','P') IS NOT NULL DROP PROCEDURE sp_CreateReservacion;
GO
CREATE PROCEDURE sp_CreateReservacion
  @NumeroReserva     NVARCHAR(50),
  @ClienteID         INT,
  @HabitacionID      INT,
  @FechaIngreso      DATETIME,
  @FechaSalida       DATETIME,
  @CantidadPersonas  INT,
  @PoseeVehiculo     BIT
AS
BEGIN
  INSERT INTO Reservaciones(
    NumeroReserva,ClienteID,HabitacionID,FechaIngreso,FechaSalida,CantidadPersonas,PoseeVehiculo
  ) VALUES(
    @NumeroReserva,@ClienteID,@HabitacionID,@FechaIngreso,@FechaSalida,@CantidadPersonas,@PoseeVehiculo
  );
  SELECT SCOPE_IDENTITY() AS NewID;
END;
GO

-- READ
IF OBJECT_ID('sp_GetReservaciones','P') IS NOT NULL DROP PROCEDURE sp_GetReservaciones;
GO
CREATE PROCEDURE sp_GetReservaciones
  @ClienteID INT=NULL,
  @Desde     DATETIME=NULL,
  @Hasta     DATETIME=NULL
AS
BEGIN
  SELECT r.ReservacionID, r.NumeroReserva,
         c.Nombre+' '+c.PrimerApellido AS Cliente,
         h.NumeroHabitacion AS Habitacion,
         r.FechaIngreso, r.FechaSalida,
         r.CantidadPersonas,
         CASE WHEN r.PoseeVehiculo=1 THEN 'S�' ELSE 'No' END AS Vehiculo
  FROM Reservaciones r
  JOIN Clientes c     ON r.ClienteID=c.ClienteID
  JOIN Habitaciones h ON r.HabitacionID=h.HabitacionID
  WHERE (@ClienteID IS NULL OR r.ClienteID=@ClienteID)
    AND (@Desde      IS NULL OR r.FechaIngreso>=@Desde)
    AND (@Hasta      IS NULL OR r.FechaSalida<=@Hasta);
END;
GO

-- UPDATE
IF OBJECT_ID('sp_UpdateReservacion','P') IS NOT NULL DROP PROCEDURE sp_UpdateReservacion;
GO
CREATE PROCEDURE sp_UpdateReservacion
  @ReservacionID     INT,
  @FechaIngreso      DATETIME=NULL,
  @FechaSalida       DATETIME=NULL,
  @CantidadPersonas  INT=NULL,
  @PoseeVehiculo     BIT=NULL
AS
BEGIN
  UPDATE Reservaciones
  SET FechaIngreso     = COALESCE(@FechaIngreso, FechaIngreso),
      FechaSalida      = COALESCE(@FechaSalida, FechaSalida),
      CantidadPersonas = COALESCE(@CantidadPersonas, CantidadPersonas),
      PoseeVehiculo    = COALESCE(@PoseeVehiculo, PoseeVehiculo)
  WHERE ReservacionID=@ReservacionID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- DELETE
IF OBJECT_ID('sp_DeleteReservacion','P') IS NOT NULL DROP PROCEDURE sp_DeleteReservacion;
GO
CREATE PROCEDURE sp_DeleteReservacion
  @ReservacionID INT
AS
BEGIN
  DELETE FROM Reservaciones WHERE ReservacionID=@ReservacionID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

--------------------------------------------------------------------------------
-- 6. CRUD: Facturacion
--------------------------------------------------------------------------------
-- CREATE
IF OBJECT_ID('sp_CreateFacturacion','P') IS NOT NULL DROP PROCEDURE sp_CreateFacturacion;
GO
CREATE PROCEDURE sp_CreateFacturacion
  @ReservacionID INT,
  @NochesEstadia INT,
  @ImporteTotal  DECIMAL(10,2),
  @MetodoPago    NVARCHAR(50)
AS
BEGIN
  INSERT INTO Facturacion(ReservacionID,NochesEstadia,ImporteTotal,MetodoPago)
  VALUES(@ReservacionID,@NochesEstadia,@ImporteTotal,@MetodoPago);
  SELECT SCOPE_IDENTITY() AS NewID;
END;
GO

-- READ
IF OBJECT_ID('sp_GetFacturacion','P') IS NOT NULL DROP PROCEDURE sp_GetFacturacion;
GO
CREATE PROCEDURE sp_GetFacturacion
  @Desde      DATETIME=NULL,
  @Hasta      DATETIME=NULL,
  @MetodoPago NVARCHAR(50)=NULL
AS
BEGIN
  SELECT f.FacturacionID, r.NumeroReserva, f.NochesEstadia, f.ImporteTotal, f.MetodoPago
  FROM Facturacion f
  JOIN Reservaciones r ON f.ReservacionID=r.ReservacionID
  WHERE (@Desde      IS NULL OR r.FechaIngreso>=@Desde)
    AND (@Hasta      IS NULL OR r.FechaSalida<=@Hasta)
    AND (@MetodoPago IS NULL OR f.MetodoPago=@MetodoPago);
END;
GO


-- Sin filtros (trae todo):
EXEC sp_GetFacturacion;

-- Con fecha de inicio:
EXEC sp_GetFacturacion @Desde = '2025-06-01';

-- Con rango de fechas y m�todo de pago:
EXEC sp_GetFacturacion @Desde = '2025-06-01', @Hasta = '2025-06-30', @MetodoPago = 'efectivo';






-- UPDATE
IF OBJECT_ID('sp_UpdateFacturacion','P') IS NOT NULL DROP PROCEDURE sp_UpdateFacturacion;
GO
CREATE PROCEDURE sp_UpdateFacturacion
  @FacturacionID INT,
  @NochesEstadia INT=NULL,
  @ImporteTotal  DECIMAL(10,2)=NULL,
  @MetodoPago    NVARCHAR(50)=NULL
AS
BEGIN
  UPDATE Facturacion
  SET NochesEstadia = COALESCE(@NochesEstadia, NochesEstadia),
      ImporteTotal  = COALESCE(@ImporteTotal, ImporteTotal),
      MetodoPago    = COALESCE(@MetodoPago, MetodoPago)
  WHERE FacturacionID=@FacturacionID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- DELETE
IF OBJECT_ID('sp_DeleteFacturacion','P') IS NOT NULL DROP PROCEDURE sp_DeleteFacturacion;
GO
CREATE PROCEDURE sp_DeleteFacturacion
  @FacturacionID INT
AS
BEGIN
  DELETE FROM Facturacion WHERE FacturacionID=@FacturacionID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

--------------------------------------------------------------------------------
-- 7. CRUD: ActividadesRecreacion
--------------------------------------------------------------------------------
-- CREATE
IF OBJECT_ID('sp_CreateActividad','P') IS NOT NULL DROP PROCEDURE sp_CreateActividad;
GO
CREATE PROCEDURE sp_CreateActividad
  @EstablecimientoID INT,
  @NombreEmpresa     NVARCHAR(100),
  @CedulaJuridica    NVARCHAR(20),
  @Email             NVARCHAR(100),
  @Telefono          NVARCHAR(20),
  @NombreContacto    NVARCHAR(100),
  @Provincia         NVARCHAR(50),
  @Canton            NVARCHAR(50),
  @Distrito          NVARCHAR(50),
  @Senas             NVARCHAR(200),
  @TipoActividad     NVARCHAR(200),
  @Descripcion       NVARCHAR(200)=NULL,
  @Precio            DECIMAL(10,2)
AS
BEGIN
  INSERT INTO ActividadesRecreacion(
    EstablecimientoID,NombreEmpresa,CedulaJuridica,Email,Telefono,
    NombreContacto,Provincia,Canton,Distrito,Senas,TipoActividad,Descripcion,Precio
  ) VALUES(
    @EstablecimientoID,@NombreEmpresa,@CedulaJuridica,@Email,@Telefono,
    @NombreContacto,@Provincia,@Canton,@Distrito,@Senas,@TipoActividad,@Descripcion,@Precio
  );
  SELECT SCOPE_IDENTITY() AS NewID;
END;
GO


-- READ
IF OBJECT_ID('sp_GetActividades', 'P') IS NOT NULL
    DROP PROCEDURE sp_GetActividades;
GO

CREATE PROCEDURE sp_GetActividades
AS
BEGIN
    SELECT * FROM vw_ActividadesConHotel
    ORDER BY ActividadID DESC;
END;
GO

-- Buscar Actividades
IF OBJECT_ID('sp_BuscarActividades', 'P') IS NOT NULL
    DROP PROCEDURE sp_BuscarActividades;
GO
CREATE OR ALTER PROCEDURE sp_BuscarActividades
    @Empresa NVARCHAR(100) = NULL,
    @Tipo NVARCHAR(100) = NULL,
    @Provincia NVARCHAR(100) = NULL
AS
BEGIN
    SELECT * 
    FROM vw_ActividadesConDetalles
    WHERE (@Empresa IS NULL OR NombreEmpresa LIKE '%' + @Empresa + '%')
      AND (@Tipo IS NULL OR TipoActividad LIKE '%' + @Tipo + '%')
      AND (@Provincia IS NULL OR Provincia LIKE '%' + @Provincia + '%')
    ORDER BY NombreEmpresa ASC;
END;



EXEC sp_BuscarActividades @Empresa = NULL, @Tipo = NULL, @Provincia = NULL;



-- UPDATE
IF OBJECT_ID('sp_UpdateActividad','P') IS NOT NULL DROP PROCEDURE sp_UpdateActividad;
GO
CREATE PROCEDURE sp_UpdateActividad
  @ActividadID       INT,
  @NombreEmpresa     NVARCHAR(100)=NULL,
  @Email             NVARCHAR(100)=NULL,
  @Telefono          NVARCHAR(20)=NULL,
  @NombreContacto    NVARCHAR(100)=NULL,
  @Provincia         NVARCHAR(50)=NULL,
  @Canton            NVARCHAR(50)=NULL,
  @Distrito          NVARCHAR(50)=NULL,
  @Senas             NVARCHAR(200)=NULL,
  @TipoActividad     NVARCHAR(200)=NULL,
  @Descripcion       NVARCHAR(200)=NULL,
  @Precio            DECIMAL(10,2)=NULL
AS
BEGIN
  UPDATE ActividadesRecreacion
  SET NombreEmpresa  = COALESCE(@NombreEmpresa, NombreEmpresa),
      Email          = COALESCE(@Email, Email),
      Telefono       = COALESCE(@Telefono, Telefono),
      NombreContacto = COALESCE(@NombreContacto, NombreContacto),
      Provincia      = COALESCE(@Provincia, Provincia),
      Canton         = COALESCE(@Canton, Canton),
      Distrito       = COALESCE(@Distrito, Distrito),
      Senas          = COALESCE(@Senas, Senas),
      TipoActividad  = COALESCE(@TipoActividad, TipoActividad),
      Descripcion    = COALESCE(@Descripcion, Descripcion),
      Precio         = COALESCE(@Precio, Precio)
  WHERE ActividadID=@ActividadID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- Update 2.0
IF OBJECT_ID('sp_UpdateActividad2','P') IS NOT NULL DROP PROCEDURE sp_UpdateActividad;
GO
CREATE PROCEDURE sp_UpdateActividad2
  @ActividadID       INT,
  @EstablecimientoID INT,
  @NombreEmpresa     NVARCHAR(100),
  @CedulaJuridica    NVARCHAR(20),
  @Email             NVARCHAR(100),
  @Telefono          NVARCHAR(20),
  @NombreContacto    NVARCHAR(100),
  @Provincia         NVARCHAR(50),
  @Canton            NVARCHAR(50),
  @Distrito          NVARCHAR(50),
  @Senas             NVARCHAR(200),
  @TipoActividad     NVARCHAR(200),
  @Descripcion       NVARCHAR(200),
  @Precio            DECIMAL(10,2)
AS
BEGIN
  UPDATE ActividadesRecreacion
  SET
    EstablecimientoID = @EstablecimientoID,
    NombreEmpresa     = @NombreEmpresa,
    CedulaJuridica    = @CedulaJuridica,
    Email             = @Email,
    Telefono          = @Telefono,
    NombreContacto    = @NombreContacto,
    Provincia         = @Provincia,
    Canton            = @Canton,
    Distrito          = @Distrito,
    Senas             = @Senas,
    TipoActividad     = @TipoActividad,
    Descripcion       = @Descripcion,
    Precio            = @Precio
  WHERE ActividadID = @ActividadID;

  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO




-- DELETE
IF OBJECT_ID('sp_DeleteActividad','P') IS NOT NULL DROP PROCEDURE sp_DeleteActividad;
GO
CREATE PROCEDURE sp_DeleteActividad
  @ActividadID INT
AS
BEGIN
  DELETE FROM ActividadesRecreacion WHERE ActividadID=@ActividadID;
  SELECT @@ROWCOUNT AS RowsAffected;
END;
GO

-- ==========================================================
-- 8. REPORTES (Nueva funcionalidad)
-- Incluye procedimientos para facturaci�n, uso por tipo,
-- edad de clientes y demanda de hoteles
-- ==========================================================

-- 1. Reporte de facturacion
IF OBJECT_ID('sp_ReportFacturacion','P') IS NOT NULL
    DROP PROCEDURE sp_ReportFacturacion;
GO
CREATE PROCEDURE sp_ReportFacturacion
  @Desde           DATETIME      = NULL,
  @Hasta           DATETIME      = NULL,
  @Agrupamiento    NVARCHAR(10)  = 'DIA',      -- 'DIA','MES','ANIO'
  @TipoHabitacion  NVARCHAR(50)  = NULL,       -- NULL = todos
  @HabitacionID    INT           = NULL        -- NULL = todos
AS
BEGIN
  SET NOCOUNT ON;

  ;WITH Datos AS (
    SELECT 
      CASE 
        WHEN @Agrupamiento = 'DIA'  THEN CONVERT(CHAR(10), r.FechaIngreso, 120)  -- 'YYYY-MM-DD'
        WHEN @Agrupamiento = 'MES'  THEN CONVERT(CHAR(7),  r.FechaIngreso, 120)  -- 'YYYY-MM'
        WHEN @Agrupamiento = 'ANIO' THEN CONVERT(CHAR(4),  r.FechaIngreso, 120)  -- 'YYYY'
      END AS Periodo,
      f.ImporteTotal
    FROM Facturacion f
    JOIN Reservaciones  r ON f.ReservacionID = r.ReservacionID
    JOIN Habitaciones   h ON r.HabitacionID   = h.HabitacionID
    JOIN TiposHabitacion t ON h.TipoHabitacionID = t.TipoHabitacionID
    WHERE (@Desde          IS NULL OR r.FechaIngreso >= @Desde)
      AND (@Hasta          IS NULL OR r.FechaIngreso <= @Hasta)
      AND (@TipoHabitacion IS NULL OR t.Nombre = @TipoHabitacion)
      AND (@HabitacionID   IS NULL OR h.HabitacionID = @HabitacionID)
  )
  SELECT
    Periodo,
    COUNT(*)            AS NumFacturas,
    SUM(ImporteTotal)   AS TotalFacturado
  FROM Datos
  GROUP BY Periodo
  ORDER BY Periodo;
END;
GO

-- 2. Reporte de uso por tipo habitacion
IF OBJECT_ID('sp_ReportUsoPorTipo','P') IS NOT NULL
    DROP PROCEDURE sp_ReportUsoPorTipo;
GO
CREATE PROCEDURE sp_ReportUsoPorTipo
  @Desde         DATETIME    = NULL,
  @Hasta         DATETIME    = NULL,
  @Tipos         NVARCHAR(200)= NULL   -- lista separada por comas: 'Suite, Doble'
AS
BEGIN
  SET NOCOUNT ON;

  -- Convertir la cadena de tipos a tabla
  DECLARE @TiposTabla TABLE (Nombre NVARCHAR(50));
  INSERT INTO @TiposTabla
  SELECT LTRIM(RTRIM(value))
  FROM STRING_SPLIT(@Tipos, ',');

  SELECT
    t.Nombre               AS TipoHabitacion,
    COUNT(r.ReservacionID) AS NumReservas,
    SUM(DATEDIFF(day, r.FechaIngreso, r.FechaSalida)) AS TotalNoches
  FROM Reservaciones r
  JOIN Habitaciones h       ON r.HabitacionID = h.HabitacionID
  JOIN TiposHabitacion t    ON h.TipoHabitacionID = t.TipoHabitacionID
  WHERE r.FechaSalida <= GETDATE()    -- s�lo finalizadas
    AND (@Desde IS NULL OR r.FechaIngreso >= @Desde)
    AND (@Hasta IS NULL OR r.FechaSalida <= @Hasta)
    AND (
      @Tipos  IS NULL
      OR EXISTS (
        SELECT 1 FROM @TiposTabla tt WHERE tt.Nombre = t.Nombre
      )
    )
  GROUP BY t.Nombre
  ORDER BY NumReservas DESC;
END;
GO

-- 3. Reporte por rango de edades de clientes
IF OBJECT_ID('sp_ReportEdadClientes','P') IS NOT NULL
    DROP PROCEDURE sp_ReportEdadClientes;
GO
CREATE PROCEDURE sp_ReportEdadClientes
  @Desde   DATETIME = NULL,
  @Hasta   DATETIME = NULL
AS
BEGIN
  SET NOCOUNT ON;

  ;WITH EdadCTE AS (
    SELECT
      DATEDIFF(year, c.FechaNacimiento, r.FechaIngreso)
      - CASE 
          WHEN MONTH(r.FechaIngreso) < MONTH(c.FechaNacimiento)
            OR (MONTH(r.FechaIngreso)=MONTH(c.FechaNacimiento) 
                AND DAY(r.FechaIngreso) < DAY(c.FechaNacimiento))
          THEN 1 ELSE 0
        END AS Edad
    FROM Reservaciones r
    JOIN Clientes c ON r.ClienteID = c.ClienteID
    WHERE (@Desde IS NULL OR r.FechaIngreso >= @Desde)
      AND (@Hasta IS NULL OR r.FechaIngreso <= @Hasta)
  )
  SELECT TOP 1
    MIN(Edad)          OVER ()               AS EdadMinima,
    MAX(Edad)          OVER ()               AS EdadMaxima,
    ROUND(AVG(CAST(Edad AS FLOAT)) OVER (), 0) AS EdadPromedio
  FROM EdadCTE;
END;
GO


-- 4. Reporte de hoteles de mayor demanda
IF OBJECT_ID('sp_ReportHotelesDemanda','P') IS NOT NULL
    DROP PROCEDURE sp_ReportHotelesDemanda;
GO
CREATE PROCEDURE sp_ReportHotelesDemanda
  @Desde     DATETIME    = NULL,
  @Hasta     DATETIME    = NULL,
  @Provincia NVARCHAR(50)= NULL,
  @Canton    NVARCHAR(50)= NULL
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    e.EstablecimientoID,
    e.NombreHotel,
    e.Provincia,
    e.Canton,
    COUNT(r.ReservacionID) AS NumReservas,
    SUM(DATEDIFF(day, r.FechaIngreso, r.FechaSalida)) AS TotalNoches
  FROM Reservaciones r
  JOIN Habitaciones h       ON r.HabitacionID = h.HabitacionID
  JOIN Establecimientos e    ON h.EstablecimientoID = e.EstablecimientoID
  WHERE (@Desde     IS NULL OR r.FechaIngreso >= @Desde)
    AND (@Hasta     IS NULL OR r.FechaSalida <= @Hasta)
    AND (@Provincia IS NULL OR e.Provincia = @Provincia)
    AND (@Canton    IS NULL OR e.Canton    = @Canton)
  GROUP BY
    e.EstablecimientoID,
    e.NombreHotel,
    e.Provincia,
    e.Canton
  ORDER BY NumReservas DESC;
END;
GO


--------------------------------------------------------------------------------
-- PRUEBAS DE FUNCIONALIDAD CRUD (ejemplos)
--------------------------------------------------------------------------------
-- Establecimientos
--EXEC sp_CreateEstablecimiento 'Test Hotel', '123456789','Hotel','Lim�n','Lim�n','Lim�n','Centro','Al lado del mar','N/A','8888-8888','test@hotel.com','https://hotel.test','fb/test','insta/test','yt/test','tt/test','abnb/test','thrds/test','x/test','WiFi;Desayuno';
--EXEC sp_GetEstablecimientos @Nombre='Test';
--EXEC sp_UpdateEstablecimiento 1, @Facebook='fb/updated';
--EXEC sp_DeleteEstablecimiento 1;

-- TiposHabitacion
--EXEC sp_CreateTipoHabitacion 'Presidencial', 'Espacioso', 'WiFi,A/C', 120000, NULL;
--EXEC sp_GetTiposHabitacion @PrecioMin=100000;
--EXEC sp_UpdateTipoHabitacion 1, @Precio=130000;
--EXEC sp_DeleteTipoHabitacion 1;

-- Habitaciones
--EXEC sp_CreateHabitacion '999',1,1;
--EXEC sp_GetHabitaciones @EstablecimientoID=1;
--EXEC sp_UpdateHabitacion 1, @NumeroHabitacion='998';
--EXEC sp_DeleteHabitacion 1;

-- Clientes
--EXEC sp_CreateCliente 'Carlos','Molina','Rojas','1980-01-01','C�dula','20202020','Costa Rica','Limon','Siquirres','Siquirres','123','111','222','Carlos@gmail';
--EXEC sp_GetClientes @PaisResidencia='Costa Rica';
--EXEC sp_UpdateCliente 1, @Email='cmolina@ejemplo.com';
--EXEC sp_DeleteCliente 1;

-- Reservaciones
--EXEC sp_CreateReservacion 'RSV-5001',1,1,'2025-08-01 14:00:00','2025-08-03 11:00:00',2,0;
--EXEC sp_GetReservaciones @Desde='2025-08-01', @Hasta='2025-08-31';
--EXEC sp_UpdateReservacion 1, @CantidadPersonas=3;
--EXEC sp_DeleteReservacion 1;

-- Facturacion
--EXEC sp_CreateFacturacion 1,2,90000,'efectivo';
--EXEC sp_GetFacturacion @MetodoPago='efectivo';
--EXEC sp_UpdateFacturacion 1, @ImporteTotal=95000;
--EXEC sp_DeleteFacturacion 1;

-- ActividadesRecreacion
--EXEC sp_CreateActividad 1,'Adventure Tours','311112222','adv@tours','27770000','Laura Vega','Lim�n','Pococ�','Gu�piles','En el parque','Tour','Breve descripci�n',40000;
--EXEC sp_GetActividades @EstablecimientoID=1;
--EXEC sp_UpdateActividad 1, @Precio=45000;
--EXEC sp_DeleteActividad 1;

-- DESCOMENTAR SECCION PARA PROBAR ESAS FUNCIONALIDADES --



-- A�ADIENDO NUEVOS DATOS PARA TENER MAS EJEMPLOS DE PRUEBA --
--------------------------------------------------------------------------------
-- 1. Datos de prueba: Establecimientos
--------------------------------------------------------------------------------
INSERT INTO Establecimientos (NombreHotel, CedulaJuridica, Tipo, Provincia, Canton, Distrito, Barrio, Senas, Referencia, Telefonos, Email, URLSitioWeb, Facebook, Instagram, YouTube, TikTok, Airbnb, Threads, X_Red, ListaServicios)
VALUES
('Hotel Costa Azul', '3100105012', 'Hotel',     'Lim�n',      'Lim�n',      'Central',  'Cariari',     'Frente al mar',        'Junto al muelle',   '2755-1234', 'info@costaazul.cr',    'https://costaazul.cr', 'fb/costaazul', 'ig/costaazul', NULL, NULL, NULL, NULL, NULL, 'Piscina;WiFi;Restaurante'),
('Hostal La Ceiba', '3100204023', 'Hostal',    'Puntarenas', 'Puntarenas', 'Barrio 1', 'La Ceiba',    'Cerca del centro',     NULL,                '2222-5678', 'contacto@laceiba.cr',  NULL,                 NULL,         NULL, NULL, NULL, NULL, NULL,NULL, 'WiFi;Desayuno'),
('Casa Verde',      '3100303034', 'Casa',      'Alajuela',   'Alajuela',   'Gu�cima',  'Bella Vista', 'A 200m de la carretera','Frente a gasolinera','2444-9101', 'reservas@casaverde.cr',NULL,              NULL,         NULL, NULL, NULL, NULL, NULL, NULL, 'Cocina;Jard�n'),
('Ecolodge R�o Claro','3100402025','Ecolodge',  'Cartago',    'Oreamuno',   'R�o Claro','Sector El R�o','Orillas del r�o',      '500m del puente',   '2555-3344', 'info@rioclaro.cr',     'https://rioclaro.cr',   NULL,         NULL, NULL, NULL, NULL, NULL,NULL, 'Senderos;Kayak;WiFi'),
('Resort Para�so',  '3100501016', 'Resort',    'Guanacaste', 'Liberia',    'Ca�as Dulces','Bah�a Azul','Junto a playa privada',NULL,                '2666-7788', 'ventas@paraiso.cr',    'https://paraiso.cr',    'fb/paraiso', 'ig/paraiso', NULL, NULL, NULL, NULL,NULL, 'Spa;Golf;Piscina;WiFi');
GO

--------------------------------------------------------------------------------
-- 2. Datos de prueba: TiposHabitacion
--------------------------------------------------------------------------------
INSERT INTO TiposHabitacion (Nombre, Descripcion, Comodidades, Precio, Fotos)
VALUES
('Estandar',   'Habitaci�n sencilla',       'WiFi,A/C',                50000,  NULL),
('Doble',      'Dos camas individuales',    'WiFi,A/C',                75000,  NULL),
('Matrimonial','Cama matrimonial',         'WiFi,A/C,TV',             90000,  NULL),
('Suite',      'Espaciosa con sala',        'WiFi,A/C,TV,MiniBar',    150000,  NULL),
('Presidencial','M�xima comodidad',        'WiFi,A/C,TV,MiniBar,Spa', 250000,  NULL);
GO

--------------------------------------------------------------------------------
-- 3. Datos de prueba: Habitaciones
--------------------------------------------------------------------------------
DECLARE @EstID INT, @TipoID INT, @Nombre NVARCHAR(50);

DECLARE est CURSOR FOR 
  SELECT EstablecimientoID FROM Establecimientos;
OPEN est;
FETCH NEXT FROM est INTO @EstID;
WHILE @@FETCH_STATUS = 0
BEGIN
  DECLARE tipo CURSOR FOR 
    SELECT TipoHabitacionID, Nombre FROM TiposHabitacion;
  OPEN tipo;
  FETCH NEXT FROM tipo INTO @TipoID, @Nombre;
  WHILE @@FETCH_STATUS = 0
  BEGIN
    INSERT INTO Habitaciones (EstablecimientoID, NumeroHabitacion, TipoHabitacionID)
    VALUES
      (@EstID, CONCAT(@TipoID, '0', @EstID, 'A'), @TipoID),
      (@EstID, CONCAT(@TipoID, '0', @EstID, 'B'), @TipoID),
      (@EstID, CONCAT(@TipoID, '0', @EstID, 'C'), @TipoID);

    FETCH NEXT FROM tipo INTO @TipoID, @Nombre;
  END
  CLOSE tipo;
  DEALLOCATE tipo;

  FETCH NEXT FROM est INTO @EstID;
END
CLOSE est;
DEALLOCATE est;
GO

--------------------------------------------------------------------------------
-- 4. Datos de prueba: Clientes
--------------------------------------------------------------------------------
INSERT INTO Clientes (Nombre, PrimerApellido, SegundoApellido, FechaNacimiento, TipoIdentificacion, Cedula, PaisResidencia, Provincia, Canton, Distrito, Telefono1, Email, Usuario, Clave)
VALUES
('Mar�a',   'Gonz�lez', 'P�rez',   '1985-03-12', 'C�dula', '10505050', 'Costa Rica', 'San Jos�',    'Escaz�', 'San Rafael', '8888-0001', 'maria.gp@mail.com', 'cliente1', 'cliente123'),
('Juan',    'Rodr�guez','Cordero','1990-07-22', 'C�dula', '20506060', 'Costa Rica', 'Heredia',     'Bel�n',   'San Antonio', '8888-0002', 'juan.rc@mail.com', 'cliente2', 'cliente123'),
('Ana',     'S�nchez',  'Morales','1978-11-05', 'C�dula', '30507070', 'Costa Rica', 'Cartago',     'Para�so', 'Orosi',       '8888-0003', 'ana.sm@mail.com', 'cliente3', 'cliente123'),
('Luis',    'Fern�ndez','Vargas', '2000-05-30', 'Pasaporte', 'X1234567','M�xico',     NULL,        NULL,        NULL,          '8888-0004', 'luis.fv@mail.mx', 'cliente4', 'cliente123'),
('Karla',   'Jim�nez',  'Ruiz',    '1995-01-15', 'C�dula', '40508080', 'Costa Rica', 'Alajuela',    'Alajuela','Sabanilla',   '8888-0005', 'karla.jr@mail.com', 'cliente5', 'cliente123');
GO

--------------------------------------------------------------------------------
-- 4,5. Datos de prueba: Administradores
--------------------------------------------------------------------------------
INSERT INTO Administradores (usuario, clave)
VALUES 
('admin1', 'admin123'),
('admin2', 'admin123');
GO

--------------------------------------------------------------------------------
-- 5. Datos de prueba: Reservaciones y Facturaci�n
--------------------------------------------------------------------------------
-- Creamos varias reservas con fechas sueltas en 2025
INSERT INTO Reservaciones (NumeroReserva, ClienteID, HabitacionID, FechaIngreso, FechaSalida, CantidadPersonas, PoseeVehiculo)
VALUES
('R-2025-001', 1,  1, '2025-01-05 14:00', '2025-01-07 11:00', 2, 1),
('R-2025-002', 2,  5, '2025-02-10 15:00', '2025-02-12 10:00', 1, 0),
('R-2025-003', 3, 10, '2025-03-20 12:00', '2025-03-22 12:00', 3, 1),
('R-2025-004', 4, 15, '2025-04-01 16:00', '2025-04-05 10:00', 2, 0),
('R-2025-005', 5, 20, '2025-05-10 14:00', '2025-05-15 11:00', 4, 1),
('R-2025-006', 1,  2, '2025-06-01 13:00', '2025-06-03 11:00', 2, 0),
('R-2025-007', 2,  6, '2025-06-10 14:00', '2025-06-12 12:00', 1, 0);
GO

-- Facturaci�n correspondiente
INSERT INTO Facturacion (ReservacionID, NochesEstadia, ImporteTotal, MetodoPago)
SELECT
  r.ReservacionID,
  DATEDIFF(day, r.FechaIngreso, r.FechaSalida),
  DATEDIFF(day, r.FechaIngreso, r.FechaSalida) * t.Precio,
  CASE WHEN r.PoseeVehiculo = 1 THEN 'tarjeta de cr�dito' ELSE 'efectivo' END
FROM Reservaciones r
JOIN Habitaciones h        ON r.HabitacionID = h.HabitacionID
JOIN TiposHabitacion t     ON h.TipoHabitacionID = t.TipoHabitacionID;
GO

--------------------------------------------------------------------------------
-- 6. Datos de prueba: ActividadesRecreacion
--------------------------------------------------------------------------------
INSERT INTO ActividadesRecreacion (EstablecimientoID, NombreEmpresa, CedulaJuridica, Email, Telefono, NombreContacto, Provincia, Canton, Distrito, Senas, TipoActividad, Descripcion, Precio)
VALUES
(1, 'Ocean Tours S.A.',      '900010101', 'ocean@tours.com',      '27770010', 'Carlos M�ndez',   'Lim�n',    'Lim�n',   'Central', 'Muelle 3',       'Tour en catamar�n',      'Paseo en catamar�n con snorkel', 60000),
(2, 'Monteverde Adventures', '900020202', 'monteverde@adv.com',   '26550020', 'Laura Castro',    'Puntarenas','Puntarenas','Monteverde','Carretera principal','Canopy y puentes colgantes','Tour de canopy de 8 cables',120000),
(4, 'R�o Claro Kayaks',      '900030303', 'kayak@rioclaro.com',    '25550030', 'Jorge Ram�rez',   'Cartago',  'Oreamuno','R�o Claro','Entrada parque', 'Alquiler de kayaks',      'Kayak en aguas tranquilas', 35000),
(5, 'Paraiso Golf Club',     '900040404', 'golf@paraiso.com',      '26660040', 'Ana Villalobos',  'Guanacaste','Liberia','Ca�as Dulces','Junto al campo de golf','Green fee',               'Acceso 18 hoyos',               80000);
GO

PRINT 'Datos de prueba insertados correctamente.';

-- REALIZACION DE PRUEBAS CON LOS NUEVOS REPORTES O FILTROS --

-- Facturaci�n agrupada por mes, de enero a junio de 2025
EXEC sp_ReportFacturacion 
  @Desde        = '2025-01-01', 
  @Hasta        = '2025-06-30', 
  @Agrupamiento = 'MES';



EXEC sp_ReportFacturacion 
  @Desde        = '2025-01-01', 
  @Hasta        = '2025-06-30', 
  @Agrupamiento = 'MES',
  @TipoHabitacion = NULL,
  @HabitacionID = NULL;



-- Uso de habitaciones finalizadas hasta hoy, entre enero y junio, para tipos 'Estandar' y 'Doble'
EXEC sp_ReportUsoPorTipo 
  @Desde = '2025-01-01', 
  @Hasta = '2025-06-30', 
  @Tipos = 'Estandar,Doble';

-- Rango de edades de clientes para reservas entre enero y junio de 2025
EXEC sp_ReportEdadClientes 
  @Desde = '2025-01-01', 
  @Hasta = '2025-06-30';

-- Hoteles con m�s reservas entre marzo y mayo de 2025, s�lo en Lim�n
EXEC sp_ReportHotelesDemanda
  @Desde     = '2025-03-01',
  @Hasta     = '2025-05-31',
  @Provincia = 'Lim�n',
  @Canton    = NULL;






--------------------------------------------------------------------------------
-- VISTAS Y PROCEDIMIENTOS DE LA APP WEB
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Vista para buscar hoteles
-- Eliminar la vista si ya existe
IF OBJECT_ID('vw_hoteles_info', 'V') IS NOT NULL
    DROP VIEW vw_hoteles_info;
GO

-- Crear la vista
CREATE VIEW vw_hoteles_info AS
SELECT EstablecimientoID, NombreHotel, Tipo, Provincia, Telefonos, Email
FROM Establecimientos;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Eliminar el procedimiento si ya existe
IF OBJECT_ID('sp_buscar_hoteles', 'P') IS NOT NULL
    DROP PROCEDURE sp_buscar_hoteles;
GO

-- Crear el procedimiento
CREATE PROCEDURE sp_buscar_hoteles
    @nombre NVARCHAR(100) = NULL,
    @provincia NVARCHAR(100) = NULL,
    @tipo NVARCHAR(100) = NULL
AS
BEGIN
    SELECT *
    FROM vw_hoteles_info
    WHERE (@nombre IS NULL OR NombreHotel LIKE '%' + @nombre + '%')
      AND (@provincia IS NULL OR Provincia LIKE '%' + @provincia + '%')
      AND (@tipo IS NULL OR Tipo LIKE '%' + @tipo + '%')
    ORDER BY NombreHotel ASC;
END;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Vista para ver establecimientos
-- Eliminar la vista si ya existe
IF OBJECT_ID('vw_establecimientos_admin', 'V') IS NOT NULL
    DROP VIEW vw_establecimientos_admin;
GO

-- Crear la vista
CREATE VIEW vw_establecimientos_admin AS
SELECT EstablecimientoID, NombreHotel, CedulaJuridica, Tipo,
       Provincia, Canton, Distrito, Telefonos, Email
FROM Establecimientos;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Eliminar el procedimiento si ya existe
IF OBJECT_ID('sp_listar_establecimientos', 'P') IS NOT NULL
    DROP PROCEDURE sp_listar_establecimientos;
GO

-- Crear el procedimiento
CREATE PROCEDURE sp_listar_establecimientos
AS
BEGIN
    SELECT * FROM vw_establecimientos_admin
    ORDER BY EstablecimientoID DESC;
END;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Eliminar el procedimiento si ya existe
IF OBJECT_ID('sp_insertar_establecimiento', 'P') IS NOT NULL
    DROP PROCEDURE sp_insertar_establecimiento;
GO

CREATE PROCEDURE sp_insertar_establecimiento
    @NombreHotel NVARCHAR(100),
    @CedulaJuridica NVARCHAR(50),
    @Tipo NVARCHAR(50),
    @Provincia NVARCHAR(50),
    @Canton NVARCHAR(50),
    @Distrito NVARCHAR(50),
    @Barrio NVARCHAR(50),
    @Senas NVARCHAR(200),
    @Referencia NVARCHAR(200),
    @Telefonos NVARCHAR(100),
    @Email NVARCHAR(100),
    @URLSitioWeb NVARCHAR(200),
    @Facebook NVARCHAR(200),
    @Instagram NVARCHAR(200),
    @YouTube NVARCHAR(200),
    @TikTok NVARCHAR(200),
    @Threads NVARCHAR(200),
    @X_Red NVARCHAR(200),
    @ListaServicios NVARCHAR(500)
AS
BEGIN
    INSERT INTO Establecimientos (
        NombreHotel, CedulaJuridica, Tipo, Provincia, Canton, Distrito, Barrio, Senas,
        Referencia, Telefonos, Email, URLSitioWeb, Facebook, Instagram, YouTube,
        TikTok, Threads, X_Red, ListaServicios
    )
    VALUES (
        @NombreHotel, @CedulaJuridica, @Tipo, @Provincia, @Canton, @Distrito, @Barrio, @Senas,
        @Referencia, @Telefonos, @Email, @URLSitioWeb, @Facebook, @Instagram, @YouTube,
        @TikTok, @Threads, @X_Red, @ListaServicios
    );
END;
GO

--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Vista para ver establecimientos
-- Eliminar la vista si ya existe

IF OBJECT_ID('vw_establecimiento_detalle', 'V') IS NOT NULL
    DROP VIEW vw_establecimiento_detalle;
GO

CREATE VIEW vw_establecimiento_detalle AS
SELECT *
FROM Establecimientos;
GO

--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Eliminar el procedimiento si ya existe
IF OBJECT_ID('sp_obtener_establecimiento_por_id', 'P') IS NOT NULL
    DROP PROCEDURE sp_obtener_establecimiento_por_id;
GO

CREATE PROCEDURE sp_obtener_establecimiento_por_id
    @id INT
AS
BEGIN
    SELECT * FROM vw_establecimiento_detalle WHERE EstablecimientoID = @id;
END;
GO

--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Eliminar el procedimiento si ya existe
IF OBJECT_ID('sp_actualizar_establecimiento', 'P') IS NOT NULL
    DROP PROCEDURE sp_actualizar_establecimiento;
GO

CREATE PROCEDURE sp_actualizar_establecimiento
    @EstablecimientoID INT,
    @NombreHotel NVARCHAR(100),
    @CedulaJuridica NVARCHAR(50),
    @Tipo NVARCHAR(50),
    @Provincia NVARCHAR(50),
    @Canton NVARCHAR(50),
    @Distrito NVARCHAR(50),
    @Barrio NVARCHAR(50),
    @Senas NVARCHAR(200),
    @Referencia NVARCHAR(200),
    @Telefonos NVARCHAR(100),
    @Email NVARCHAR(100),
    @URLSitioWeb NVARCHAR(200),
    @Facebook NVARCHAR(200),
    @Instagram NVARCHAR(200),
    @YouTube NVARCHAR(200),
    @TikTok NVARCHAR(200),
    @Threads NVARCHAR(200),
    @X_Red NVARCHAR(200),
    @ListaServicios NVARCHAR(500)
AS
BEGIN
    UPDATE Establecimientos SET 
        NombreHotel = @NombreHotel,
        CedulaJuridica = @CedulaJuridica,
        Tipo = @Tipo,
        Provincia = @Provincia,
        Canton = @Canton,
        Distrito = @Distrito,
        Barrio = @Barrio,
        Senas = @Senas,
        Referencia = @Referencia,
        Telefonos = @Telefonos,
        Email = @Email,
        URLSitioWeb = @URLSitioWeb,
        Facebook = @Facebook,
        Instagram = @Instagram,
        YouTube = @YouTube,
        TikTok = @TikTok,
        Threads = @Threads,
        X_Red = @X_Red,
        ListaServicios = @ListaServicios
    WHERE EstablecimientoID = @EstablecimientoID;
END;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Vista para ver establecimientos
-- Eliminar la vista si ya existe
IF OBJECT_ID('vw_TiposHabitacion', 'V') IS NOT NULL
    DROP VIEW vw_TiposHabitacion;
GO

CREATE VIEW vw_TiposHabitacion AS
SELECT TipoHabitacionID, Nombre, Descripcion, Comodidades, Precio, Fotos
FROM TiposHabitacion;
GO

--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Eliminar el procedimiento si ya existe
IF OBJECT_ID('sp_GetTipoHabitacionByID', 'P') IS NOT NULL
    DROP PROCEDURE sp_GetTipoHabitacionByID;
GO

CREATE PROCEDURE sp_GetTipoHabitacionByID
    @TipoHabitacionID INT
AS
BEGIN
    SELECT TipoHabitacionID, Nombre, Descripcion, Comodidades, Precio, Fotos
    FROM TiposHabitacion
    WHERE TipoHabitacionID = @TipoHabitacionID;
END;
GO

--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Vista para ver establecimientos
-- Eliminar la vista si ya existe
IF OBJECT_ID('vw_ActividadesConHotel', 'V') IS NOT NULL
    DROP VIEW vw_ActividadesConHotel;
GO

CREATE VIEW vw_ActividadesConHotel AS
SELECT 
    ar.ActividadID,
    e.NombreHotel,
    ar.NombreEmpresa,
    ar.TipoActividad,
    ar.Precio
FROM ActividadesRecreacion ar
JOIN Establecimientos e ON ar.EstablecimientoID = e.EstablecimientoID;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Vista para ver establecimientos
-- Eliminar la vista si ya existe
IF OBJECT_ID('vw_HabitacionesExtendida', 'V') IS NOT NULL
    DROP VIEW vw_HabitacionesExtendida;
GO

CREATE VIEW vw_HabitacionesExtendida AS
SELECT 
    h.HabitacionID,
    h.NumeroHabitacion,
    h.EstablecimientoID,
    h.TipoHabitacionID,
    e.NombreHotel,
    th.Nombre AS TipoNombre
FROM Habitaciones h
JOIN Establecimientos e ON h.EstablecimientoID = e.EstablecimientoID
JOIN TiposHabitacion th ON h.TipoHabitacionID = th.TipoHabitacionID;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Vista para ver establecimientos
-- Eliminar la vista si ya existe
IF OBJECT_ID('vw_Clientes', 'V') IS NOT NULL
    DROP VIEW vw_Clientes;
GO

-- VISTA GENERAL DE CLIENTES
GO
CREATE OR ALTER VIEW vw_Clientes
AS
SELECT * FROM Clientes;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Vista para ver establecimientos
-- Eliminar la vista si ya existe
IF OBJECT_ID('vw_ActividadesConDetalles ', 'V') IS NOT NULL
    DROP VIEW vw_ActividadesConDetalles ;
GO
CREATE OR ALTER VIEW vw_ActividadesConDetalles AS
SELECT
    ActividadID,
    NombreEmpresa,
    TipoActividad,
    Provincia,
    Canton,
    Distrito,
    Senas,
    Descripcion,
    Precio,
    NombreContacto,
    Email,
    Telefono
FROM ActividadesRecreacion;
GO
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Eliminar la vista si ya existe
IF OBJECT_ID('vw_EmpresasAliadas', 'V') IS NOT NULL
    DROP VIEW vw_EmpresasAliadas;
GO

-- Crear la vista SIN ORDER BY
CREATE VIEW vw_EmpresasAliadas AS
SELECT 
    ActividadID,
    NombreEmpresa,
    Telefono,
    Email,
    Provincia,
    Canton,
    Distrito,
    Senas,
    TipoActividad,
    NombreContacto,
    Precio,
    Descripcion
FROM ActividadesRecreacion;
GO






























